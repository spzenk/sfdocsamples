/*
 * 
'------------------------------------------------------------------------------
' NotifyIcon2CS                                                     (15/Ene/02)
' Segunda prueba de mostrar icono en la barra de tareas con C#
'
' Se usa el control NotifyIcon y un ContextMenu creado en ejecuci�n
' Tambi�n se asignan los eventos de los men�s en runtime (ejecuci�n)
'
' En C# se pueden asignar los procedimientos de eventos 
' directamente a los controles, as� como al formulario.
' (como se hac�a en la Preview del VB.NET)
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
 * 
 */
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace NotifyIcon2CS
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		//' Se declaran como variables los objetos NotifyIcon y el ContextMenu
		NotifyIcon NotifyIcon1 = new NotifyIcon();
		ContextMenu ContextMenu1 = new ContextMenu();
		
		internal System.Windows.Forms.Button btnSalir;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnSalir = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnSalir
			// 
			this.btnSalir.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btnSalir.Location = new System.Drawing.Point(316, 236);
			this.btnSalir.Name = "btnSalir";
			this.btnSalir.TabIndex = 0;
			this.btnSalir.Text = "Salir";
			this.btnSalir.Click += new System.EventHandler(this.Salir_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(404, 271);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnSalir});
			this.Name = "Form1";
			this.Text = "Prueba 2 de icono en la barra de tareas (C#)";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Salir_Click(object sender, System.EventArgs e)
		{
			//' Este procedimiento se usa para cerrar el formulario,
			//' se usar� como procedimiento de eventos, en principio usado por el bot�n Salir
			this.Close();
		}

		private void Restaurar_Click(object sender, System.EventArgs e)
		{
			//' Restaurar por si se minimiz�
			//' Este evento manejar� tanto los men�s Restaurar como el NotifyIcon.DoubleClick
			Show();
			WindowState = FormWindowState.Normal;
			Activate();
		}

		private void AcercaDe_Click(object sender, System.EventArgs e)
		{
			//' Mostrar la informaci�n del autor, versi�n, etc.
			MessageBox.Show(Application.ProductName + " v" + Application.ProductVersion, "Prueba 2 de NotifyIcon en C#");
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			//' Asignar los submen�s del ContextMenu
			//'
			//' A�adimos la opci�n Restaurar, que ser� el elemento predeterminado
//			MenuItem tMenu = new MenuItem("&Restaurar", new EventHandler(this.Restaurar_Click));
//			tMenu.DefaultItem = true;
//			ContextMenu1.MenuItems.Add(tMenu);
			//
			//' Esto tambi�n se puede hacer as�:
			ContextMenu1.MenuItems.Add("&Restaurar", new EventHandler(this.Restaurar_Click));
			ContextMenu1.MenuItems[0].DefaultItem = true;
			//'
			//' A�adimos un separador
			ContextMenu1.MenuItems.Add("-");
			//' A�adimos el elemento Acerca de...
			ContextMenu1.MenuItems.Add("&Acerca de...", new EventHandler(this.AcercaDe_Click));
			//' A�adimos otro separador
			ContextMenu1.MenuItems.Add("-");
			//' A�adimos la opci�n de salir
			ContextMenu1.MenuItems.Add("&Salir", new EventHandler(this.Salir_Click));
			//'
			//' Asignar los valores para el NotifyIcon
			NotifyIcon1.Icon = this.Icon;
			NotifyIcon1.ContextMenu = this.ContextMenu1;
			NotifyIcon1.Text = Application.ProductName;
			NotifyIcon1.Visible = true;
			//
			// Asignamos los otros eventos al formulario
			this.Resize += new EventHandler(this.Form1_Resize);
			this.Activated += new EventHandler(this.Form1_Activated);
			this.Closing += new System.ComponentModel.CancelEventHandler(this.Form1_Closing);
			// Asignamos el evento DoubleClick del NotifyIcon
			this.NotifyIcon1.DoubleClick += new EventHandler(this.Restaurar_Click);
		}

		private void Form1_Resize(object sender, System.EventArgs e)
		{
			//' Cuando se minimice, ocultarla, se quedar� disponible en la barra de tareas
			if( this.WindowState == FormWindowState.Minimized )
				this.Visible = false;
		}

		// la declaramos fuera de la funci�n, para que mantenga su valor
		Boolean PrimeraVez = true;
		//
		private void Form1_Activated(object sender, System.EventArgs e)
		{
			// En C# no se puede usar static para hacer que una variable mantenga su valor
			// en C/C++ s� que se puede
			//static Boolean PrimeraVez = true;
			//
			//' La primera vez que se active, ocultar el form,
			//' es una chapuza, pero el formulario no permite que se oculte en el Form_Load
			if( PrimeraVez )
			{
				PrimeraVez = false;
				Visible = false;
			}
		}

		private void Form1_Closing(object sender, System.ComponentModel.CancelEventArgs e)
		{
			// Cuando se va a cerrar el formulario...
			// eliminar el objeto de la barra de tareas
			this.NotifyIcon1.Visible = false; 
			// esto es necesario, para que no se quede el icono en la barra de tareas
			// (el cual se quita al pasar el rat�n por encima)
			this.NotifyIcon1 = null; 
			// de paso eliminamos el men� contextual
			this.ContextMenu1 = null; 
		}
	}
}
