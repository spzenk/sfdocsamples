/*
 * 
'------------------------------------------------------------------------------
' NotifyIconCS                                                      (15/Ene/02)
' Prueba de mostrar icono en la barra de tareas con C#
'
' Se usa el control NotifyIcon y un ContextMenu asignado en tiempo de dise�o
'
' �Guillermo 'guille' Som, 2002
'------------------------------------------------------------------------------
 * 
 */
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace NotifyIconCS
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		#region Declaraci�n de controles del formulario
		internal System.Windows.Forms.Button btnSalir;
		internal System.Windows.Forms.MenuItem mncSalir;
		internal System.Windows.Forms.MenuItem MenuItem5;
		internal System.Windows.Forms.MenuItem mncRestaurar;
		internal System.Windows.Forms.MenuItem mncAcercaDe;
		internal System.Windows.Forms.MenuItem MenuItem2;
		internal System.Windows.Forms.ContextMenu ContextMenu1;
		internal System.Windows.Forms.NotifyIcon NotifyIcon1;
		internal System.Windows.Forms.MenuItem mnuEdi;
		internal System.Windows.Forms.MenuItem mnuCortar;
		internal System.Windows.Forms.MenuItem mnuCopiar;
		internal System.Windows.Forms.MenuItem mnuPegar;
		internal System.Windows.Forms.MenuItem MenuItem20;
		internal System.Windows.Forms.MenuItem mnuSeleccionarTodo;
		internal System.Windows.Forms.MenuItem MenuItem15;
		internal System.Windows.Forms.MainMenu MainMenu1;
		internal System.Windows.Forms.MenuItem mnuFic;
		internal System.Windows.Forms.MenuItem mnuRestaurar;
		internal System.Windows.Forms.MenuItem mnuAbrir;
		internal System.Windows.Forms.MenuItem mnuGuardar;
		internal System.Windows.Forms.MenuItem mnuGuardarComo;
		internal System.Windows.Forms.MenuItem MenuItem10;
		internal System.Windows.Forms.MenuItem mnuAcercaDe;
		internal System.Windows.Forms.MenuItem MenuItem12;
		internal System.Windows.Forms.MenuItem mnuSalir;
		private System.ComponentModel.IContainer components;
		#endregion

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.mnuAbrir = new System.Windows.Forms.MenuItem();
			this.mnuGuardar = new System.Windows.Forms.MenuItem();
			this.mnuRestaurar = new System.Windows.Forms.MenuItem();
			this.MenuItem2 = new System.Windows.Forms.MenuItem();
			this.mncSalir = new System.Windows.Forms.MenuItem();
			this.NotifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
			this.mnuAcercaDe = new System.Windows.Forms.MenuItem();
			this.MenuItem20 = new System.Windows.Forms.MenuItem();
			this.mnuFic = new System.Windows.Forms.MenuItem();
			this.MenuItem15 = new System.Windows.Forms.MenuItem();
			this.mnuGuardarComo = new System.Windows.Forms.MenuItem();
			this.MenuItem10 = new System.Windows.Forms.MenuItem();
			this.MenuItem12 = new System.Windows.Forms.MenuItem();
			this.mnuSalir = new System.Windows.Forms.MenuItem();
			this.mnuSeleccionarTodo = new System.Windows.Forms.MenuItem();
			this.MainMenu1 = new System.Windows.Forms.MainMenu();
			this.mnuEdi = new System.Windows.Forms.MenuItem();
			this.mnuCortar = new System.Windows.Forms.MenuItem();
			this.mnuCopiar = new System.Windows.Forms.MenuItem();
			this.mnuPegar = new System.Windows.Forms.MenuItem();
			this.mncAcercaDe = new System.Windows.Forms.MenuItem();
			this.MenuItem5 = new System.Windows.Forms.MenuItem();
			this.btnSalir = new System.Windows.Forms.Button();
			this.ContextMenu1 = new System.Windows.Forms.ContextMenu();
			this.mncRestaurar = new System.Windows.Forms.MenuItem();
			this.SuspendLayout();
			// 
			// mnuAbrir
			// 
			this.mnuAbrir.Index = 2;
			this.mnuAbrir.Text = "&Abrir...";
			// 
			// mnuGuardar
			// 
			this.mnuGuardar.Index = 3;
			this.mnuGuardar.Text = "&Guardar";
			// 
			// mnuRestaurar
			// 
			this.mnuRestaurar.Index = 0;
			this.mnuRestaurar.Text = "&Restaurar";
			this.mnuRestaurar.Click += new System.EventHandler(this.Restaurar_Click);
			// 
			// MenuItem2
			// 
			this.MenuItem2.Index = 1;
			this.MenuItem2.Text = "-";
			// 
			// mncSalir
			// 
			this.mncSalir.Index = 4;
			this.mncSalir.Text = "&Salir";
			this.mncSalir.Click += new System.EventHandler(this.Salir_Click);
			// 
			// NotifyIcon1
			// 
			this.NotifyIcon1.Text = "NotifyIcon1";
			this.NotifyIcon1.Visible = true;
			this.NotifyIcon1.DoubleClick += new System.EventHandler(this.Restaurar_Click);
			// 
			// mnuAcercaDe
			// 
			this.mnuAcercaDe.Index = 6;
			this.mnuAcercaDe.Text = "Acerca de...";
			this.mnuAcercaDe.Click += new System.EventHandler(this.AcercaDe_Click);
			// 
			// MenuItem20
			// 
			this.MenuItem20.Index = 3;
			this.MenuItem20.Text = "-";
			// 
			// mnuFic
			// 
			this.mnuFic.Index = 0;
			this.mnuFic.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				   this.mnuRestaurar,
																				   this.MenuItem15,
																				   this.mnuAbrir,
																				   this.mnuGuardar,
																				   this.mnuGuardarComo,
																				   this.MenuItem10,
																				   this.mnuAcercaDe,
																				   this.MenuItem12,
																				   this.mnuSalir});
			this.mnuFic.Text = "&Ficheros";
			// 
			// MenuItem15
			// 
			this.MenuItem15.Index = 1;
			this.MenuItem15.Text = "-";
			// 
			// mnuGuardarComo
			// 
			this.mnuGuardarComo.Index = 4;
			this.mnuGuardarComo.Text = "G&uardar como...";
			// 
			// MenuItem10
			// 
			this.MenuItem10.Index = 5;
			this.MenuItem10.Text = "-";
			// 
			// MenuItem12
			// 
			this.MenuItem12.Index = 7;
			this.MenuItem12.Text = "-";
			// 
			// mnuSalir
			// 
			this.mnuSalir.Index = 8;
			this.mnuSalir.Text = "Salir";
			this.mnuSalir.Click += new System.EventHandler(this.Salir_Click);
			// 
			// mnuSeleccionarTodo
			// 
			this.mnuSeleccionarTodo.Index = 4;
			this.mnuSeleccionarTodo.Text = "Seleccionar todo";
			// 
			// MainMenu1
			// 
			this.MainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.mnuFic,
																					  this.mnuEdi});
			// 
			// mnuEdi
			// 
			this.mnuEdi.Index = 1;
			this.mnuEdi.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																				   this.mnuCortar,
																				   this.mnuCopiar,
																				   this.mnuPegar,
																				   this.MenuItem20,
																				   this.mnuSeleccionarTodo});
			this.mnuEdi.Text = "&Edici�n";
			// 
			// mnuCortar
			// 
			this.mnuCortar.Index = 0;
			this.mnuCortar.Text = "Cortar";
			// 
			// mnuCopiar
			// 
			this.mnuCopiar.Index = 1;
			this.mnuCopiar.Text = "Copiar";
			// 
			// mnuPegar
			// 
			this.mnuPegar.Index = 2;
			this.mnuPegar.Text = "Pegar";
			// 
			// mncAcercaDe
			// 
			this.mncAcercaDe.Index = 2;
			this.mncAcercaDe.Text = "&Acerca de...";
			this.mncAcercaDe.Click += new System.EventHandler(this.AcercaDe_Click);
			// 
			// MenuItem5
			// 
			this.MenuItem5.Index = 3;
			this.MenuItem5.Text = "-";
			// 
			// btnSalir
			// 
			this.btnSalir.Anchor = (System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right);
			this.btnSalir.Location = new System.Drawing.Point(316, 215);
			this.btnSalir.Name = "btnSalir";
			this.btnSalir.TabIndex = 0;
			this.btnSalir.Text = "Salir";
			this.btnSalir.Click += new System.EventHandler(this.Salir_Click);
			// 
			// ContextMenu1
			// 
			this.ContextMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.mncRestaurar,
																						 this.MenuItem2,
																						 this.mncAcercaDe,
																						 this.MenuItem5,
																						 this.mncSalir});
			// 
			// mncRestaurar
			// 
			this.mncRestaurar.DefaultItem = true;
			this.mncRestaurar.Index = 0;
			this.mncRestaurar.Text = "&Restaurar";
			this.mncRestaurar.Click += new System.EventHandler(this.Restaurar_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(404, 250);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.btnSalir});
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Menu = this.MainMenu1;
			this.Name = "Form1";
			this.Text = "Prueba de icono en la barra de tareas (C#)";
			this.Resize += new System.EventHandler(this.Form1_Resize);
			this.Load += new System.EventHandler(this.Form1_Load);
			this.Activated += new System.EventHandler(this.Form1_Activated);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void Salir_Click(object sender, System.EventArgs e)
		{
			//' Este evento controla tanto el Click del bot�n como de los men�s Salir
			this.Close(); 
		}

		private void Restaurar_Click(object sender, System.EventArgs e)
		{
			//' Restaurar por si se minimiz�
			//' Este evento manejar� tanto los men�s Restaurar como el NotifyIcon.DoubleClick
			Show();
			WindowState = FormWindowState.Normal;
			Activate();
		}

		private void AcercaDe_Click(object sender, System.EventArgs e)
		{
			//' Mostrar la informaci�n del autor, versi�n, etc.
			MessageBox.Show(Application.ProductName + " v" + Application.ProductVersion, "Prueba NotifyIcon en C#");
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			//' Asignar los valores para el NotifyIcon
			NotifyIcon1.Icon = this.Icon;
			NotifyIcon1.ContextMenu = this.ContextMenu1;
			NotifyIcon1.Text = Application.ProductName;
			NotifyIcon1.Visible = true;
		}

		private void Form1_Resize(object sender, System.EventArgs e)
		{
			//' Cuando se minimice, ocultarla, se quedar� disponible en la barra de tareas
			if( this.WindowState == FormWindowState.Minimized )
				this.Visible = false;
		}

		// la declaramos fuera de la funci�n, para que mantenga su valor
		Boolean PrimeraVez = true;
		//
		private void Form1_Activated(object sender, System.EventArgs e)
		{
			// En C# no se puede usar static para hacer que una variable mantenga su valor
			// en C/C++ s� que se puede
			//static Boolean PrimeraVez = true;
			//
			//' La primera vez que se active, ocultar el form,
			//' es una chapuza, pero el formulario no permite que se oculte en el Form_Load
			if( PrimeraVez )
			{
				PrimeraVez = false;
				Visible = false;
			}
		}
	}
}
