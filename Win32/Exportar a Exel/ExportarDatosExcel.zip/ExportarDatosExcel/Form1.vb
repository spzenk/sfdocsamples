Imports ExportarDatosExcel.Funciones

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents dgDatos As System.Windows.Forms.DataGrid
    Friend WithEvents btnExportar As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.dgDatos = New System.Windows.Forms.DataGrid
        Me.btnExportar = New System.Windows.Forms.Button
        CType(Me.dgDatos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgDatos
        '
        Me.dgDatos.DataMember = ""
        Me.dgDatos.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dgDatos.Location = New System.Drawing.Point(8, 8)
        Me.dgDatos.Name = "dgDatos"
        Me.dgDatos.Size = New System.Drawing.Size(344, 192)
        Me.dgDatos.TabIndex = 0
        '
        'btnExportar
        '
        Me.btnExportar.Location = New System.Drawing.Point(248, 208)
        Me.btnExportar.Name = "btnExportar"
        Me.btnExportar.Size = New System.Drawing.Size(104, 24)
        Me.btnExportar.TabIndex = 1
        Me.btnExportar.Text = "Exportar"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(360, 238)
        Me.Controls.Add(Me.btnExportar)
        Me.Controls.Add(Me.dgDatos)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.dgDatos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnExportar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExportar.Click
        Try
            Dim iExp As New Funciones
            iExp.DataTableToExcel(CType(Me.dgDatos.DataSource, DataTable))

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Dim dt As New DataTable
            Dim dr As DataRow

            dt.Columns.Add(New DataColumn("Codigo", GetType(String)))
            dt.Columns.Add(New DataColumn("Descripcion", GetType(String)))
            dt.Columns.Add(New DataColumn("Valor", GetType(Integer)))

            dr = dt.NewRow()
            dr("Codigo") = "A"
            dr("Descripcion") = "Activo"
            dr("Valor") = 1
            dt.Rows.Add(dr)

            dr = dt.NewRow()
            dr("Codigo") = "I"
            dr("Descripcion") = "Inactivo"
            dr("Valor") = 2
            dt.Rows.Add(dr)

            dr = dt.NewRow()
            dr("Codigo") = "B"
            dr("Descripcion") = "Bloqueado"
            dr("Valor") = 3
            dt.Rows.Add(dr)

            Me.dgDatos.DataSource = dt
        Catch ex As Exception

        End Try
    End Sub
End Class
