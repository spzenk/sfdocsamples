using System;
//Word.dll
using Word;

	/// <summary>
	/// Test Harness for SpellCheck Class
	/// </summary>
	class TestHarness
	{
		/// <summary>
		/// testing Word Class
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			SpellCheck word = new SpellCheck();

			bool status = false;
			string s = "youes";

			Console.WriteLine("Checking for word : " + s );
			
			// check to see if the word is not correct or not 
			// return the bool (true|false)
			status = word.CheckSpelling(s);

			if (status == false)
			{
				Console.WriteLine("This word is misspelled : " + s);
				Console.WriteLine("Here are some suggestions");
				Console.WriteLine("-------------------------");

				foreach( string suggestion in word.GetSpellingSuggestions(s) ) 
				{
					System.Console.WriteLine( suggestion ); 
				}
			}
			else if (status == true)
			{
				Console.WriteLine("This word is correct : " + s );
			}

		}
	}
