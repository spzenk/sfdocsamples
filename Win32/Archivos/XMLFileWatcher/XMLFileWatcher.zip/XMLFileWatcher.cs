using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using System.IO;
using System.Web.Mail;
using System.Data.SqlClient;

namespace XMLFileWatcher
{
	public class XMLWatcher : System.ServiceProcess.ServiceBase
	{
		private System.ComponentModel.IContainer components=null;
		private System.Diagnostics.EventLog el=null;
		private System.IO.FileSystemWatcher  fsWatcher=null;
		private System.Web.Mail.MailMessage mailMsg=null;
		

		public XMLWatcher()
		{
			// This call is required by the Windows.Forms Component Designer.
			InitializeComponent();
			
			// TODO: Add any initialization after the InitComponent call
		}

		// The main entry point for the process
		static void Main()
		{
			System.ServiceProcess.ServiceBase[] ServicesToRun;
	
			// More than one user Service may run within the same process. To add
			// another service to this process, change the following line to
			// create a second service object. For example,
			//
			//   ServicesToRun = new System.ServiceProcess.ServiceBase[] {new Service1(), new MySecondUserService()};
			//
			ServicesToRun = new System.ServiceProcess.ServiceBase[] { new XMLWatcher() };

			System.ServiceProcess.ServiceBase.Run(ServicesToRun);	
			
		}

		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// Set the Service Name as "XMLWatcher"
			this.ServiceName = "XMLWatcher";
		}
		/// <summary> 
		/// Initialize the Event Log
		/// 
		/// </summary>
		private void InitializEventLog()
		{
			//Check whether "XMLWatcherSource" exist or not
			if(!System.Diagnostics.EventLog.SourceExists("XMLWatcherSource"))
			{
				//Create "XMLWatcherSource" and "XMLWatcherLog"
				System.Diagnostics.EventLog.CreateEventSource("XMLWatcherSource","XMLWatcherLog");

			}
			//Create Event Log
			el=new EventLog();
			//Assign Event Log Name
			el.Log="XMLWatcherLog";
			//Assign Event Source Name
			el.Source="XMLWatcherSource";
		}
		/// <summary> 
		/// Initialize File System Watcher
		/// 
		/// </summary>
		private void IntializeFileSystemWatcher()
		{
			//Create File System Watcher for XML files
			fsWatcher=new System.IO.FileSystemWatcher("c:\\temp","*.xml");
			// Add event handlers for new XML files and change of existing XML files.
			fsWatcher.Changed += new FileSystemEventHandler(OnXMLFileChanged);
			fsWatcher.Created += new FileSystemEventHandler(OnXMLFileCreated);
			
			// Begin watching.
			fsWatcher.EnableRaisingEvents = true;

		}
		/// <summary> 
		/// Initalize Mail Server
		/// 
		/// </summary>
		private void InitializeMailServer()
		{
			mailMsg=new System.Web.Mail.MailMessage();
		}
		/// <summary> 
		/// Event Handler for File Changed  
		/// 
		/// </summary>
		private void OnXMLFileChanged(object source, FileSystemEventArgs e)
		{
			//Write entry into the Event Log
			el.WriteEntry("XML File :" + e.FullPath + " changed");

			//Send mail 
			SendMail(e.FullPath);
			
			//Get the Dataset from XML
			GetDataSetFromXML(e.FullPath);
			
		}
		/// <summary> 
		/// Event Handler for File Created 
		/// 
		/// </summary>
		private void OnXMLFileCreated(object source, FileSystemEventArgs e)
		{
			//Write entry into the Event Log
			el.WriteEntry("XML File :" + e.FullPath + " created");

			//Send mail 
			SendMail(e.FullPath);

			//Get the Dataset from XML
			GetDataSetFromXML(e.FullPath);

		}
		/// <summary> 
		/// Notify the users by sendig mail
		/// 
		/// </summary>
		private void SendMail(string XMLFileName)
		{
			string fileName=XMLFileName;
			//Message From
			mailMsg.From="admin@xxx.com";
			//Message To
			mailMsg.To="dev@xxx.com";
			//Message Subject
			mailMsg.Subject="New File Uploaded to the server ";
			//Message Body
			mailMsg.Body="XML File :" + fileName + " is uploaded ";
			//Everything set..now send the mail
			SmtpMail.Send(mailMsg);

		}

		/// <summary> 
		/// Get Dataset from XML 
		/// 
		/// </summary>
		private DataSet GetDataSetFromXML(string XMLFileName)
		{
			string uploadedXMLfile = XMLFileName;
			//Create the Dataset
			DataSet ds = new DataSet();
			// Create new FileStream with which to read the schema.
			System.IO.FileStream fsReadXml = new System.IO.FileStream
				(uploadedXMLfile, System.IO.FileMode.Open);
			try
			{
				ds.ReadXml(fsReadXml);
				
			}
			catch (Exception ex)
			{
				//Write entry into the Event Log
				el.WriteEntry("Error in readig XML File : " + uploadedXMLfile );
			}
			finally
			{
				fsReadXml.Close();
			}
			return ds;

		}
	

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		/// <summary>
		/// Set things in motion so your service can do its work.
		/// </summary>
		protected override void OnStart(string[] args)
		{
			// TODO: Add code here to start your service.

			//Initialize Event Log
			InitializEventLog();
			//Initialize File System Watcher
			IntializeFileSystemWatcher();
			//Initliaze Mail Server
			InitializeMailServer();		

		}
 
		/// <summary>
		/// Stop this service.
		/// </summary>
		protected override void OnStop()
		{
			// TODO: Add code here to perform any tear-down necessary to stop your service.


		}

		

	}
}
