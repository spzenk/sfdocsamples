using System;
using System.IO;
using System.Text;
using System.Data;
using System.Windows.Forms;
using QueryCommander.PlugIn.Core;
using QueryCommander.PlugIn.Core.Interfaces;

namespace TextFileOutput
{
	/// <summary>
	/// Summary description for Plugin_SaveFile.
	/// </summary>
	public class Plugin_SaveFile :IPlugin_OnAfterQueryExecution1
	{
		#region IPlugin_OnAfterQueryExecution1 Members

		/// <summary>
		/// Calling this method will save the result (callcontext.ResultDataSet) to a textfile.
		/// </summary>
		/// <param name="callcontext"></param>
		/// <param name="handle"></param>
		/// <param name="plugInVariables"></param>
		/// <param name="menuItem">Current menu item</param>
		/// <returns></returns>
		public object Execute(CallContext callcontext, System.IntPtr handle, System.Collections.Hashtable plugInVariables)
		{
			Guid id = new Guid("{CBCD4586-F340-4d48-9CBA-F4FBEF0166A2}");
			if( Convert.ToBoolean( plugInVariables[id] )==true)
			{
				SaveFile(callcontext.ResultDataSet,callcontext.QueryWindowContext);
			}
			

			return null;
		}

		public QueryCommander.PlugIn.Core.Common.ExecutionTypes ExecutionType
		{
			get
			{
				// There are no return values
				return QueryCommander.PlugIn.Core.Common.ExecutionTypes.None;
			}
		}

		#endregion

		/// <summary>
		/// Creates and saves the text-file
		/// </summary>
		/// <param name="ds"></param>
		/// <param name="query"></param>
		private void SaveFile(DataSet ds, string query)
		{
			string FILE_NAME	= "outPut.txt";
			string columnNames	= "";
			SaveFileDialog saveFileDialog = new SaveFileDialog();

			saveFileDialog.FileName =FILE_NAME;
			saveFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*" ;

			if(saveFileDialog.ShowDialog() == DialogResult.OK)
			{
				FILE_NAME=saveFileDialog.FileName;
				StreamWriter sr = File.CreateText(FILE_NAME);
				sr.WriteLine ("Executed: " + DateTime.Now.ToString());
				sr.WriteLine ("******************************************************************************************************");
				sr.WriteLine (query);
				sr.WriteLine ("******************************************************************************************************");
				sr.WriteLine ("");
				foreach(DataColumn col in ds.Tables[0].Columns)
				{
					columnNames+=col.ColumnName + "\t";
				}
				sr.WriteLine (columnNames);
				sr.WriteLine ("-------------------------------------------------------------------------------------------------------");
				foreach(DataRow row in ds.Tables[0].Rows)
				{
					string rowValues	= "";
					foreach(DataColumn col in ds.Tables[0].Columns)
					{
						rowValues+=row[col].ToString() + "\t";
					}
					sr.WriteLine (rowValues);															 
				}
				sr.WriteLine ("******************************************************************************************************");
				sr.WriteLine ("");
				sr.Close();
				//MessageBox.Show("Output save at " + Application.StartupPath + "\\" + FILE_NAME, "Save result to file");
			}

		}
	}
}
