using System;
using System.IO;
using System.Text;
using System.Data;
using System.Windows.Forms;
using QueryCommander.PlugIn.Core;
using QueryCommander.PlugIn.Core.Interfaces;
using CustomControls;

namespace XMLSchemaOutput
{
	/// <summary>
	/// Summary description for Plugin_SaveFile.
	/// </summary>
	public class Plugin_SaveFile :IPlugin_OnAfterQueryExecution1
	{
		#region IPlugin_OnAfterQueryExecution1 Members

		/// <summary>
		/// Calling this method will save the result (callcontext.ResultDataSet) to a textfile.
		/// </summary>
		/// <param name="callcontext"></param>
		/// <param name="handle"></param>
		/// <param name="plugInVariables"></param>
		/// <param name="menuItem">Current menu item</param>
		/// <returns></returns>
		public object Execute(CallContext callcontext, System.IntPtr handle, System.Collections.Hashtable plugInVariables)
		{
			Guid id = new Guid("{8C8DAE4F-6C58-4e4c-BEE8-1F224C4D0987}");
			if( Convert.ToBoolean( plugInVariables[id] )==true)
			{
				if (callcontext.ResultDataSet == null || callcontext.ResultDataSet.Tables.Count == 0)
				{
					MessageBox.Show("There is no valid output from this query to save as XML.", "XML Save Output!", MessageBoxButtons.OK, MessageBoxIcon.Information);
				}
				else
				{
					SaveFile(callcontext.ResultDataSet, callcontext.QueryWindowContext, handle);
				}
			}

			return null;
		}

		public QueryCommander.PlugIn.Core.Common.ExecutionTypes ExecutionType
		{
			get
			{
				// There are no return values
				return QueryCommander.PlugIn.Core.Common.ExecutionTypes.None;
			}
		}

		#endregion

		/// <summary>
		/// Creates and saves the text-file
		/// </summary>
		/// <param name="ds"></param>
		/// <param name="query"></param>
		private void SaveFile(DataSet ds, string query, System.IntPtr handle)
		{
			CustomSaveDialog ofd = new CustomSaveDialog();
			ofd.OwnerHandle = handle;
			ofd.DefaultExt = "XML";
			ofd.FileName = "Output.xml";
			ofd.xmlWriteMode = XmlWriteMode.IgnoreSchema;
			ofd.Filter = "XML files (*.xml)|*.xml|All files (*.*)|*.*";
			if (ofd.ShowDialog() == DialogResult.OK)
			{
				//MessageBox.Show(String.Format("Name={0}, XMLMode={1}", ofd.FileName, ofd.xmlWriteMode));
				ds.WriteXml(ofd.FileName, ofd.xmlWriteMode);
			}

//			string fn = "outPut.xml";
//			SaveFileDialog saveFileDialog = new SaveFileDialog();
//			saveFileDialog.Title = "Save query results as XML file";
//			saveFileDialog.FileName = fn;
//			saveFileDialog.Filter = "XML files (*.xml)|*.xml|All files (*.*)|*.*" ;
//			saveFileDialog.OverwritePrompt = true;
//			saveFileDialog.RestoreDirectory = true;
//			saveFileDialog.CheckPathExists = true;
//			saveFileDialog.AddExtension = true;
//			fn = saveFileDialog.FileName;

//			if(saveFileDialog.ShowDialog() == DialogResult.OK)
//			{
//				ds.WriteXml(ofd.FileName, XmlWriteMode.IgnoreSchema);
//			}
		}
	}
}
