using System;
using System.Windows.Forms;
using QueryCommander.PlugIn.Core;
using QueryCommander.PlugIn.Core.Interfaces;

namespace XMLSchemaOutput
{
	/// <summary>
	/// Summary description for Plugin_MenuItem.
	/// </summary>
	public class Plugin_MenuItem : IPlugin_OnMenuClick1
	{
		
		#region IPlugin_OnMenuClick1 Members
		/// <summary>
		/// Calling this method will check or uncheck the MenuItem and set a plugInVariables to true/false
		/// </summary>
		/// <param name="callcontext"></param>
		/// <param name="handle"></param>
		/// <param name="plugInVariables"></param>
		/// <param name="menuItem">Current menu item</param>
		/// <returns></returns>
		public object Execute(CallContext callcontext, System.IntPtr handle, System.Collections.Hashtable plugInVariables, System.Windows.Forms.MenuItem menuItem)
		{
			// The hashtable id used for plugInVariables.
			// This vaiable is later used in the Plugin_SaveFile class.
			Guid id = new Guid("{8C8DAE4F-6C58-4e4c-BEE8-1F224C4D0987}");

			// Checking or unchecking MenuItem and setting the plugInVariables
			if(menuItem.Checked)
			{
				menuItem.Checked=false;
				if(plugInVariables[id]==null)
					plugInVariables.Add(id,false);
				else
					plugInVariables[id]=false;
			}
			else
			{
				menuItem.Checked=true;
				if(plugInVariables[id]==null)
					plugInVariables.Add(id,true);
				else
					plugInVariables[id]=true;
			
			}
			return null;
		}

		public MenuItem MenuItem
		{
			get
			{
				MenuItem mi = new MenuItem();
				mi.OwnerDraw = true;
				mi.Text = "Save result to XML-file";
				
				return mi;
			}
		}
		
		public QueryCommander.PlugIn.Core.Common.ExecutionTypes ExecutionType
		{
			get
			{
				// There are no return values
				return QueryCommander.PlugIn.Core.Common.ExecutionTypes.None;
			}
		}

		#endregion
	}
}
