// *******************************************************************************
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// *******************************************************************************
using System;
using System.IO;
using System.Text;
using System.Collections;
using System.Xml;
using System.Xml.Serialization;
using System.Data;
using System.Text.RegularExpressions;
using System.Threading;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using FirebirdSql.Data.Firebird;
using QueryCommander.Database;
using QueryCommander.Database.Firebird.FireBirdMetaData;

namespace QueryCommander.Database.Firebird._2x
{
	/// <summary>
	/// Summary description for DataManager.
	/// </summary>
	public class DataManager : IDatabaseManager
	{
		public DataManager()
		{
			string path="QueryCommander.Database.Firebird._2x.Meta.QueryStrings.xml";
			_queryDocument=DBCommon.ReadEmbeddedResource(path);

			_commands = new QueryCommands(_queryDocument);
		}
		#region Private Members & Enums
		XmlDocument _queryDocument=null;
		private string[] _gos = new string[3] { "GO\n","GO\t"," GO "};
		//private ArrayList _Gos;
		private QueryCommands _commands;// = new DBCommands();
		private XmlDocument _xmlDocument=null;
		private FbDataAdapter _dataAdapter;
		private static ArrayList _sqlInfoMessages = new ArrayList();
		private FbCommand _currentCommand;

		#endregion	
		#region Private Methods
		private string ByteArrayToString(byte[] arrInput)
		{
			Encoding ascii = Encoding.ASCII;
			Encoding unicode = Encoding.Unicode;

			char[] asciiChars = new char[ascii.GetCharCount(arrInput, 0, arrInput.Length)];
			ascii.GetChars(arrInput, 0, arrInput.Length, asciiChars, 0);
			string asciiString = new string(asciiChars);

			return asciiString;
		}
		#endregion
		#region IDatabaseManager Members
		public DBCommands Commands
		{
			get{return null;}
		}

		public XmlDocument xmlDocument
		{
			get{return _xmlDocument;}
			set{_xmlDocument=value;}
		}

		public IDataAdapter DataAdapter
		{
			get{return _dataAdapter;}
			set{_dataAdapter=(FbDataAdapter)value;}
		}

		public string ParameterToolTip
		{
			get{return"";}
		}

		#endregion
		#region IDatabaseManager Methods
		public bool StopExecuting()
		{
			try
			{
				_currentCommand.Cancel();;
				return true;
			}
			catch
			{
				return false;
			}

		}
		
	
		public DataTable ExecuteCommand(string command, IDbConnection dataConnection)
		{
			FbDataAdapter dataAdapter;
			FbCommand     dataCommand;
			DataSet			 dataSet = new DataSet();
			DataTable        dataTable = new DataTable();
			string tableName = "Query";
			try 
			{
				dataCommand = new FbCommand(command, (FbConnection)dataConnection);	
				dataAdapter = new FbDataAdapter(dataCommand);
				dataAdapter.Fill(dataSet, tableName);
				dataTable = dataSet.Tables[tableName];
			}
			catch //(Exception ex)
			{
				return dataTable;

			}
			return dataTable;
		}

		public DataTable ExecuteCommand (string command, IDbConnection  dataConnection,string databaseName)
		{
			try{dataConnection.ChangeDatabase(databaseName);}
			catch
			{
				dataConnection = new FbConnection(dataConnection.ConnectionString);
				dataConnection.Open();
				dataConnection.ChangeDatabase(databaseName);
			}
			try
			{
				return ExecuteCommand(command,dataConnection);
			}
			catch(Exception ex)
			{
				throw(ex);
			}
		}
		
		/// <summary>
		/// The same as ExecuteCommand but returns a dataset. Primarly used for multiple queries.
		/// </summary>
		/// <param name="command"></param>
		/// <param name="dataConnection"></param>
		/// <param name="databaseName"></param>
		/// <returns></returns>
		public DataSet ExecuteCommand_DataSet (string command, IDbConnection dataConnection, string databaseName)
		{
			DataSet ds = null;
			char[] del = ";".ToCharArray() ;
			string[] commands = command.Split(del);
			for(int i=0;i<commands.Length;i++)
			{
				bool isQuery=false;
				bool isNoneQuery=false;
			
				string currentCommand = commands[i].Trim();

				if(currentCommand.Length==0)
					continue;

				if(currentCommand.ToUpper().IndexOf("SELECT")>=0 ||
					currentCommand.ToUpper().IndexOf("SHOW")>=0)
					isQuery=true;
			
				if(currentCommand.ToUpper().IndexOf("INSERT")>=0)
					isNoneQuery=true;
				else if(currentCommand.ToUpper().IndexOf("UPDATE")>=0)
					isNoneQuery=true;
				else if(currentCommand.ToUpper().IndexOf("DELETE")>=0)
					isNoneQuery=true;

				if(isQuery && isNoneQuery)
				{
					DialogResult res = System.Windows.Forms.MessageBox.Show(Localization.GetString("Database.Oracle._9i.DataManager.ExecuteCommand_DataSet1"), "Resolve statement", 
						System.Windows.Forms.MessageBoxButtons.YesNoCancel,
						System.Windows.Forms.MessageBoxIcon.Question);

					if(res==DialogResult.Yes)
					{
						DataTable dt=null;
						DataSet tmpDs = ExecuteCommand_DataSet1(currentCommand,dataConnection,databaseName,true);
						if(tmpDs.Tables.Count>0)
							dt = tmpDs.Tables[0].Copy();

						if(ds==null)
							ds=new DataSet();

						ds.Tables.Add(dt);
					}
					else if(res==DialogResult.No)
						ExecuteCommand_DataSet1(currentCommand,dataConnection,databaseName,false);

				}
				else if(isQuery)
				{
					DataTable dt=null;
					DataSet tmpDs = ExecuteCommand_DataSet1(currentCommand,dataConnection,databaseName,true);
					if(tmpDs.Tables.Count>0)
						dt = tmpDs.Tables[0].Copy();

					if(ds==null)
						ds=new DataSet();

					dt.TableName = "Query" + ds.Tables.Count.ToString();
					ds.Tables.Add(dt);
				}
				else
				{
					ExecuteCommand_DataSet1(currentCommand,dataConnection,databaseName,false);
				}
			}
			return ds;
		
		}
		private DataSet ExecuteCommand_DataSet1 (string command, IDbConnection dataConnection, string databaseName, bool IsQuery )
		{
			DataSet				dataSet = new DataSet();
			DataTable			dataTable = new DataTable();
			int length = command.Length;
			
			string tableName="Query";
			
			try 
			{	
				_currentCommand = new FbCommand(command, (FbConnection)dataConnection);
				if(IsQuery)
				{
					DataAdapter= new FbDataAdapter(_currentCommand);
					FbCommandBuilder commandBuilder = new FbCommandBuilder(_dataAdapter);
					_dataAdapter.Fill(dataSet,tableName);
					return dataSet;
				}
				else
				{
					_currentCommand.ExecuteNonQuery();
					return null;
				}
			}
			catch(Exception ex)
			{
				throw(ex);
			}
			return dataSet;
		}

		
		public string GetUpdateStatements(string command, IDbConnection dataConnection, string databaseName)
		{
			throw new Exception(Localization.GetString("General.MethodNotImplemented"));
		}

		public string GetInsertStatements(string command, IDbConnection dataConnection, string databaseName)
		{
			throw new Exception(Localization.GetString("General.MethodNotImplemented"));
		}

		public string GetXmlDoc(string DBName, IDbConnection dataConnection, string whereConditions)
		{
			throw new Exception(Localization.GetString("General.MethodNotImplemented"));
		}

		public string GetCreateTableString(string tableName, IDbConnection dataConnection, string databaseName)
		{
			throw new Exception(Localization.GetString("General.MethodNotImplemented"));
		}
		public string GetCreateJobString(string JobName, string DBName, IDbConnection dataConnection)
		{
			throw new Exception(Localization.GetString("General.MethodNotImplemented"));
		}
		/// <summary>
		/// Returns ALL database objects. Used to populate the Object browser
		/// </summary>
		/// <param name="ServerName"></param>
		/// <param name="dataConnection"></param>
		/// <returns></returns>
		public ArrayList GetDatabasesObjects(string ServerName, IDbConnection dataConnection)
		{
			ArrayList Result = new ArrayList();
			FbConnection connection = (FbConnection)dataConnection;
			DataTable dsTables = connection.GetSchema("Tables");
			
			DB db = new DB();
			db.Server = connection.Database.Substring(0,connection.Database.IndexOf("."));
			db.Name = connection.Database.Substring(0,connection.Database.IndexOf("."));

			// Tables
			foreach(DataRow tableRow in dsTables.Rows)
			{
				string tableName = tableRow["TABLE_NAME"].ToString();
				
				if(tableRow["TABLE_TYPE"].ToString().ToUpper()!="TABLE")
					continue;

				DBObject dbObject = new DBObject();
				dbObject.Name = tableName;
				dbObject.Type = "U ";
				db.dbObjects.Add(dbObject);
			}

			// Views
			dsTables = connection.GetSchema("Views");
			foreach(DataRow tableRow in dsTables.Rows)
			{
				string tableName = tableRow["VIEW_NAME"].ToString();
				
				DBObject dbObject = new DBObject();
				dbObject.Name = tableName;
				dbObject.Type = "V ";
				db.dbObjects.Add(dbObject);
			}

			// Procedures
			dsTables = connection.GetSchema("Procedures");
			foreach(DataRow tableRow in dsTables.Rows)
			{
				string tableName = tableRow["PROCEDURE_NAME"].ToString();
				
				DBObject dbObject = new DBObject();
				dbObject.Name = tableName;
				dbObject.Type = "P ";
				db.dbObjects.Add(dbObject);
			}

			// Functions
			dsTables = connection.GetSchema("Functions");
			foreach(DataRow tableRow in dsTables.Rows)
			{
				string tableName = tableRow["FUNCTION_NAME"].ToString();
				
				DBObject dbObject = new DBObject();
				dbObject.Name = tableName;
				dbObject.Type = "FN ";
				db.dbObjects.Add(dbObject);
			}

			Result.Add(db);
			
			return Result;
		}

		/// <summary>
		/// Returns all database objects matching [likeChar]. This method is used for IntelliSence
		/// </summary>
		/// <param name="DBName"></param>
		/// <param name="likeChar"></param>
		/// <param name="dataConnection"></param>
		/// <returns></returns>
		public ArrayList GetDatabasesObjects(string DBName, string likeChar, IDbConnection dataConnection)
		{
			DB db = (DB)GetDatabasesObjects("",dataConnection)[0];
			ArrayList		 Result = new ArrayList();
			likeChar=likeChar.Replace("*",".*");
			Regex r = new Regex(@"\b"+likeChar, RegexOptions.IgnoreCase);
				
			foreach(DBObject dbObject in db.dbObjects)
			{
				Match m =r.Match(dbObject.Name);
				if(m.Success)
					Result.Add(dbObject);
			}

			return Result;
		}

		/// <summary>
		/// Returns all columns for a given table or view
		/// </summary>
		/// <param name="DBName"></param>
		/// <param name="objectName"></param>
		/// <param name="dataConnection"></param>
		/// <returns></returns>
		public ArrayList GetDatabasesObjectProperties(string DBName, string objectName, IDbConnection dataConnection)
		{
			ArrayList		 Result = new ArrayList();
			FbConnection connection = (FbConnection)dataConnection;
			DataTable dsColumns = connection.GetSchema("Columns");

			foreach(DataRow tableRow in dsColumns.Rows)
			{
				string tableName = tableRow["TABLE_NAME"].ToString();
				
				if(objectName.ToUpper()!=tableName.ToUpper())
					continue;

				DBObjectProperties dbObjectProperties = new DBObjectProperties();
				dbObjectProperties.Name = tableRow["COLUMN_NAME"].ToString();
				Result.Add(dbObjectProperties);
			}

			return Result;
		}

		public ArrayList GetDatabasesTriggers(string DBName, string objectName, IDbConnection dataConnection)
		{
			// TODO
			return null;
		}

		public ArrayList GetDataBaseUDTs(string DBName, IDbConnection dataConnection)
		{
			// TODO
			return null;
		}

		public ArrayList GetDataBaseDefaults(string DBName, IDbConnection dataConnection)
		{
			// TODO
			return null;
		}

		public ArrayList GetDataBaseRules(string DBName, IDbConnection dataConnection)
		{
			// TODO
			return null;
		}

		public ArrayList GetDatabaseIndexes(string DBName, string objectName, IDbConnection dataConnection)
		{
			//TODO
			return null;
		}

		public string GetCreateUDTString(DBObjectAttribute objUDT, string DBName, IDbConnection dataConnection)
		{
			// TODO
			return null;
		}

		public string GetCreateObjectString(string objectName, string DBName, IDbConnection dataConnection)
		{
			// TODO
			return null;
		}

		public ArrayList GetDatabasesReferencedObjects(string DBName, string likeChar, IDbConnection dataConnection)
		{
			throw new MinorException(Localization.GetString("Firebird.MethodNotImplemented"));
		}

		public ArrayList GetDatabasesReferencedObjectsClear(string DBName, string likeChar, IDbConnection dataConnection)
		{
			throw new MinorException(Localization.GetString("Firebird.MethodNotImplemented"));
		}

		/// <summary>
		/// Returns a table definition
		/// </summary>
		/// <param name="tableName"></param>
		/// <param name="dataConnection"></param>
		/// <param name="databaseName"></param>
		/// <returns></returns>
		public string GetObjectConstructorString(string DBName, string objectName, IDbConnection dataConnection, QueryCommander.Database.DBCommon.ScriptType scriptType, QueryCommander.Database.DBCommon.ScriptObjectType scriptObjectType)
		{
			Helper helper = new Helper((FbConnection)dataConnection, objectName);

			if(helper.Database.DatabaseTables.Count>0)
				return helper.Database.DatabaseTables[0].Definition;
			if(helper.Database.DatabaseProcedures.Count>0)
				return helper.Database.DatabaseProcedures[0].Definition;
			
			throw new MinorException(Localization.GetString("Object not found."));

		}

		#endregion		
		#region QueryCommands
		class QueryCommands
		{
			XmlDocument _queryDocument=null;
			public QueryCommands(XmlDocument doc)
			{
				_queryDocument=doc;
			}

	
			public string  CreateScript(string objectName)
			{
				return String.Format(FindQueryProvider("GetTableConstructor"),objectName);
			}
			public string GetDatabases()
			{
				return FindQueryProvider("GetDatabases");
			}
			public string GetAllTables(string database)
			{
				return String.Format(FindQueryProvider("GetAllTables"),database);
			}

			public string GetTables(string tableLikeName, string database)
			{
				return String.Format(FindQueryProvider("GetTables"),database,tableLikeName);
			}
			public string GetColumnsFromTable(string tableName, string database)
			{
				return String.Format(FindQueryProvider("GetColumnsFromTable"),database,tableName);
			}
			public string GetTableConstructor(string tableName)
			{
				return String.Format(FindQueryProvider("GetTableConstructor"),tableName);
			}
			private string FindQueryProvider(string provider)
			{
				return _queryDocument.GetElementsByTagName(provider)[0].InnerText;
			}
			
		}
		#endregion
	}
}
