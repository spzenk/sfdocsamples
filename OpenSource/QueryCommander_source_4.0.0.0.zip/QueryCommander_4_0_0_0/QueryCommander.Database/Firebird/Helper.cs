using System;
using FirebirdSql.Data.Firebird;
using System.Collections;
using System.Data;

namespace QueryCommander.Database.Firebird.FireBirdMetaData
{
	public class Helper 
	{
		#region Constructors
		public Helper(FbConnection connection)
		{
			_connection=connection;
		}
		public Helper(FbConnection connection, string objectName)
		{
			_connection=connection;
			_objectName=objectName;
		}
		#endregion
		#region Private Mambers
		FbConnection _connection=null;
		Database _database=null;
		string _objectName;
		#endregion
		#region Public Members
		public string ObjectName
		{
			get{return _objectName;}
			set{_objectName=value;}
		}
		#endregion
		#region Public methods
		public void Init()
		{
			// Get Procedure info
			DataTable allProcedures = _connection.GetSchema("PROCEDURES",new string[]{ null, null, _objectName });
			DataTable allProcedureParameters = _connection.GetSchema("PROCEDUREPARAMETERS",new string[] { null, null, _objectName });


			// Get Table info
			DataTable allTables			= _connection.GetSchema("TABLES",new string[]{ null, null, _objectName,"TABLE" });
			DataTable allTableColumns	= _connection.GetSchema("COLUMNS",new string[]{ null, null, _objectName});
			//PrimaryKeys TABLE_NAME, COLUMN_NAME
			DataTable allTable_PK_		= _connection.GetSchema("PrimaryKeys",new string[]{ null, null, _objectName});
			//ForeignKeys FK_TABLE_NAME, FK_COLUMN_NAME, PK_TABLE_NAME, PK_COLUMN_NAME
			DataTable allTable_FK		= _connection.GetSchema("ForeignKeys");//,new string[]{ null, null, null, null,null, null,null, _objectName});
			
			// Remove rows not assosiated with current object. 
			if(_objectName.Length>0)
			{
				for(int i=allTable_FK.Rows.Count-1;i>0;i--)
					if(allTable_FK.Rows[i]["FK_TABLE_NAME"].ToString()!=_objectName)
						allTable_FK.Rows.RemoveAt(i);	
			}
			Database database = new Database();
			database.Name="TESTDATABASE";
			database.DatabaseProcedures=CreateProcedures(allProcedures,allProcedureParameters);
			database.DatabaseTables=CreateTables(allTables,allTableColumns,allTable_PK_,allTable_FK);
			

			_database=database;
		}
		public Database Database
		{
			get
			{
				if(_database == null)
					Init();
				return _database;
			}
		}

		#endregion
		#region Private Methods
		private DatabaseObjectCollection CreateProcedures(DataTable procedures, DataTable procedureParameters)
		{
			DatabaseObjectCollection procedureCollection= new DatabaseObjectCollection();

			foreach(DataRow row in procedures.Rows)
			{
				string body = (string)row["SOURCE"];
				string name = (string)row["PROCEDURE_NAME"];
				string parameters="";
				string returns="";

				foreach(DataRow parameterRow in procedureParameters.Rows)
				{
					if( (string)parameterRow["PROCEDURE_NAME"]==name)
					{
						string direction = parameterRow["PARAMETER_DIRECTION"].ToString();
						string parameterName = (string)parameterRow["PARAMETER_NAME"];
						string parameterType= (string)parameterRow["PARAMETER_DATA_TYPE"];

						if(direction=="1")//Returns
							returns+="\t"+parameterName + "\t" + parameterType + ",\n";
						else
							parameters+="\t"+parameterName + "\t" + parameterType + ",\n";
					}
				}

				if(returns.Length>0)
				{
					returns = returns.TrimEnd('\n');
					returns = returns.TrimStart('\t');
					returns = "RETURNS(" +returns.TrimEnd(',') + ")\n";
				}

				if(parameters.Length>0)
				{
					parameters = parameters.TrimEnd('\n');
					parameters = parameters.TrimStart('\t');
					parameters = "(" +parameters.TrimEnd(',') + ")\n";
				}
				DatabaseObject procedure = new DatabaseObject(name,
					FireBirdMetaData.DatabaseObjectType.procedure,
					FireBirdMetaData.DatabaseObjectInstanceType.create,
					parameters,
					returns,
					body);
				procedureCollection.Add(procedure);
			}
			return procedureCollection;
		}

		private DatabaseObjectCollection CreateTables(DataTable tables, DataTable tableColumns, DataTable table_PK, DataTable table_FK)
		{
			DatabaseObjectCollection procedureCollection= new DatabaseObjectCollection();

			foreach(DataRow row in tables.Rows)
			{
				string name = (string)row["TABLE_NAME"];
				string columnstring="";

				// Columns 
				foreach(DataRow columnRow in tableColumns.Rows)
				{
					if( (string)columnRow["TABLE_NAME"]==name)
					{
						string columnName = columnRow["COLUMN_NAME"].ToString();
						string columnType = columnRow["COLUMN_DATA_TYPE"].ToString();
						string columnLength= columnRow["COLUMN_SIZE"].ToString();
						string columnPrecicion= columnRow["NUMERIC_PRECISION"].ToString();
						string columnIsNullable= columnRow["IS_NULLABLE"].ToString();
						string columnCharSet= columnRow["CHARACTER_SET_NAME"].ToString();

						columnstring+= "'" +columnName+"' "+columnType;
						if(columnCharSet.ToUpper()=="NONE")
							columnstring+="("+columnLength+")";
						
						if(columnPrecicion.Length>0)
							columnstring+="("+columnLength+","+columnPrecicion+")";
						
						if(columnIsNullable=="1")
							columnstring+= " NOT NULL";

						columnstring+=",\n\t";
					}
				}
				//PrimaryKeys TABLE_NAME, COLUMN_NAME
				//Sample:  PRIMARY KEY (fiscal_year, proj_id, dept_no),
				if(table_PK.Rows.Count>0)
				{
					string pkString ="";
					foreach(DataRow columnRow in table_PK.Rows)
					{
						if(pkString.Length==0)
							pkString = "PRIMARY KEY (";
						if( (string)columnRow["TABLE_NAME"]==name)
						{
							pkString += columnRow["COLUMN_NAME"].ToString()+",";

						}
					}
					if(pkString.Length>0)
					{
						pkString=pkString.TrimEnd(',')+")\n";
						columnstring+=pkString;
					}
				}

				//ForeignKeys FK_TABLE_NAME, FK_COLUMN_NAME, PK_TABLE_NAME, PK_COLUMN_NAME
				//Sample:	FOREIGN KEY (dept_no) REFERENCES department (dept_no),
				//			FOREIGN KEY (proj_id) REFERENCES project (proj_id)

				if(table_PK.Rows.Count>0)
				{
					string fkString ="";
					foreach(DataRow columnRow in table_FK.Rows)
					{
						if( (string)columnRow["FK_TABLE_NAME"]==name)
						{
							string fk_COLUMN_NAME = columnRow["FK_COLUMN_NAME"].ToString();
							string fk_TABLE_NAME= columnRow["PK_TABLE_NAME"].ToString();
							string pk_COLUMN_NAME= columnRow["PK_COLUMN_NAME"].ToString();
						
							fkString+= "\tFOREIGN KEY ("+fk_COLUMN_NAME+") REFERENCES " + fk_TABLE_NAME + " ("+pk_COLUMN_NAME+"),\n";

						}
					}
					if(fkString.Length>0)
					{
						fkString=fkString.TrimEnd(',')+"\n";
						columnstring+=fkString;
					}
				}

				columnstring = columnstring.TrimEnd('\n');
				columnstring = columnstring.TrimEnd(',') ;
		
				DatabaseObject procedure = new DatabaseObject(name,
					FireBirdMetaData.DatabaseObjectType.table,
					FireBirdMetaData.DatabaseObjectInstanceType.create,
					"",
					"",
					columnstring);
				procedureCollection.Add(procedure);
			}
			return procedureCollection;
		}
		#endregion
	}

	#region Firebird objects
	public enum DatabaseObjectType
	{
		database,
		table,
		view,
		procedure,
		function,
		trigger,
		udts
	}
	public enum DatabaseObjectInstanceType
	{
		create,alter
	}
	public class Database
	{
		public string Name;
		public string Definition;
		public DatabaseObjectCollection DatabaseTables=new DatabaseObjectCollection(); 
		public DatabaseObjectCollection DatabaseProcedures=new DatabaseObjectCollection(); 
		public DatabaseObjectCollection DatabaseFunctions=new DatabaseObjectCollection(); 
		public DatabaseObjectCollection DatabaseViews=new DatabaseObjectCollection(); 
	}
	public class DatabaseCollection:CollectionBase
	{
		public virtual void Add(Database NewDatabase)
		{
			this.List.Add(NewDatabase);
		}
		public virtual Database this[int Index]{get{return (Database)this.List[Index];}}
	}
	public class DatabaseObject
	{
		public DatabaseObject(
			string Name,
			DatabaseObjectType Type,
			DatabaseObjectInstanceType InstanceType,
			string Parameters,
			string Returns,
			string Body)
		{
			this.Name=Name;
			this.Type=Type;
			this.InstanceType=InstanceType;
			this.Parameters=Parameters;
			this.Returns=Returns;
			this.Body=Body;
		}

		public string Name;
		public DatabaseObjectType Type;
		public DatabaseObjectInstanceType InstanceType;
		public string Parameters;
		public string Returns;
		public string Body; 
		public string Definition
		{
			get
			{
				string ddl;
				string ret=String.Empty;
				string InstanceTypeString=InstanceType==DatabaseObjectInstanceType.create?"CREATE":"ALTER";

				switch(this.Type)
				{
					case(DatabaseObjectType.procedure):
						ddl = "{0} PROCEDURE  {1}{2}\n{3}\nAS\n{4}";
						ret = String.Format(ddl,InstanceTypeString, Name,Parameters, Returns,Body);
						break;
				
					case(DatabaseObjectType.table):
						//("create table PrepareTest(test_field varchar(20));", 
						ddl = "{0} TABLE  {1}(\n\t{2}\n)";
						ret = String.Format(ddl,InstanceTypeString, Name, Body);
						break;
				}
				return ret;
			}			
		}
	}
	public class DatabaseObjectCollection:CollectionBase
	{
		public virtual void Add(DatabaseObject NewDatabaseObject)
		{
			this.List.Add(NewDatabaseObject);
		}
		public virtual DatabaseObject this[int Index]{get{return (DatabaseObject)this.List[Index];}}
	}
	#endregion
}
