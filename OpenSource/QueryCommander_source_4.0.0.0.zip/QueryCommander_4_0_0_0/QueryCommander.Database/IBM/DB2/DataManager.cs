// *******************************************************************************
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// *******************************************************************************
using System;
using System.IO;
using System.Text;
using System.Collections;
using System.Xml;
using System.Xml.Serialization;
using System.Data;
using System.Text.RegularExpressions;
using System.Threading;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using IBM.Data.DB2;
using QueryCommander.Database;


namespace QueryCommander.Database.IBM.DB2
{
	/// <summary>
	/// Summary description for DataManager.
	/// </summary>
	public class DataManager : IDatabaseManager
	{
		#region Constructor
		public DataManager()
		{
			string path="QueryCommander.Database.IBM.DB2.Meta.QueryStrings.xml";
			_queryDocument=DBCommon.ReadEmbeddedResource(path);

			_commands = new QueryCommands(_queryDocument);
		}
		#endregion
		#region Private Members
		private DB2DataAdapter _dataAdapter;
		private static ArrayList _sqlInfoMessages = new ArrayList();
		private DB2Command _currentCommand;
		XmlDocument _queryDocument=null;
		private QueryCommands _commands;
		
		#endregion
		#region IDatabaseManager Members

		public DBCommands Commands
		{
			get{return null;}
		}

		public XmlDocument xmlDocument
		{
			get
			{
				// TODO:  Add DataManager.xmlDocument getter implementation
				return null;
			}
			set
			{
				// TODO:  Add DataManager.xmlDocument setter implementation
			}
		}

		public IDataAdapter DataAdapter
		{
			get
			{
				return _dataAdapter;
			}
			set
			{
				_dataAdapter=(DB2DataAdapter) value;
			}
		}

		public string ParameterToolTip
		{
			get
			{
				// TODO:  Add DataManager.ParameterToolTip getter implementation
				return null;
			}
		}

		
		public bool StopExecuting()
		{
			// TODO:  Add DataManager.StopExecuting implementation
			return false;
		}

		/// <summary>
		/// Executes all queries (SELECT statements) 
		/// This methods is overloaded
		/// </summary>
		/// <param name="command"></param>
		/// <param name="dataConnection"></param>
		/// <param name="databaseName"></param>
		/// <returns></returns>
		public DataTable ExecuteCommand(string command, IDbConnection dataConnection)
		{
			DB2DataAdapter dataAdapter;
			DB2Command     dataCommand;
			DataSet			 dataSet = new DataSet();
			DataTable        dataTable = new DataTable();
			string tableName = "Query";
			try 
			{
				dataCommand = new DB2Command(command, (DB2Connection)dataConnection);	
				dataAdapter = new DB2DataAdapter(dataCommand);
				dataAdapter.Fill(dataSet, tableName);
				dataTable = dataSet.Tables[tableName];
			}
			catch(Exception ex)
			{
				return dataTable;

			}
			return dataTable;
		}

		/// <summary>
		/// Executes all queries (SELECT statements) 
		/// This methods is overloaded
		/// </summary>
		/// <param name="command"></param>
		/// <param name="dataConnection"></param>
		/// <param name="databaseName"></param>
		/// <returns></returns>
		public DataTable ExecuteCommand(string command, IDbConnection dataConnection, string databaseName)
		{
			try{dataConnection.ChangeDatabase(databaseName);}
			catch
			{
				dataConnection = new DB2Connection(dataConnection.ConnectionString);
				dataConnection.Open();
				dataConnection.ChangeDatabase(databaseName);
			}
			try
			{
				return ExecuteCommand(command,dataConnection);
			}
			catch(Exception ex)
			{
				throw(ex);
			}
		}

		/// <summary>
		/// The same as ExecuteCommand but returns a dataset. Primarly used for multiple queries.
		/// </summary>
		/// <param name="command"></param>
		/// <param name="dataConnection"></param>
		/// <param name="databaseName"></param>
		/// <returns></returns>
		public DataSet ExecuteCommand_DataSet (string command, IDbConnection dataConnection, string databaseName)
		{
			DataSet ds = null;
			char[] del = ";".ToCharArray() ;
			string[] commands = command.Split(del);
			for(int i=0;i<commands.Length;i++)
			{
				bool isQuery=false;
				bool isNoneQuery=false;
			
				string currentCommand = commands[i].Trim();

				if(currentCommand.Length==0)
					continue;

				if(currentCommand.ToUpper().IndexOf("SELECT")>=0 ||
					currentCommand.ToUpper().IndexOf("SHOW")>=0)
					isQuery=true;
			
				if(currentCommand.ToUpper().IndexOf("INSERT")>=0)
					isNoneQuery=true;
				else if(currentCommand.ToUpper().IndexOf("UPDATE")>=0)
					isNoneQuery=true;
				else if(currentCommand.ToUpper().IndexOf("DELETE")>=0)
					isNoneQuery=true;

				if(isQuery && isNoneQuery)
				{
					DialogResult res = System.Windows.Forms.MessageBox.Show(Localization.GetString("Database.Oracle._9i.DataManager.ExecuteCommand_DataSet1"), "Resolve statement", 
						System.Windows.Forms.MessageBoxButtons.YesNoCancel,
						System.Windows.Forms.MessageBoxIcon.Question);

					if(res==DialogResult.Yes)
					{
						DataTable dt=null;
						DataSet tmpDs = ExecuteCommand_DataSet1(currentCommand,dataConnection,databaseName,true);
						if(tmpDs.Tables.Count>0)
							dt = tmpDs.Tables[0].Copy();

						if(ds==null)
							ds=new DataSet();

						ds.Tables.Add(dt);
					}
					else if(res==DialogResult.No)
						ExecuteCommand_DataSet1(currentCommand,dataConnection,databaseName,false);

				}
				else if(isQuery)
				{
					DataTable dt=null;
					DataSet tmpDs = ExecuteCommand_DataSet1(currentCommand,dataConnection,databaseName,true);
					if(tmpDs.Tables.Count>0)
						dt = tmpDs.Tables[0].Copy();

					if(ds==null)
						ds=new DataSet();

					dt.TableName = "Query" + ds.Tables.Count.ToString();
					ds.Tables.Add(dt);
				}
				else
				{
					ExecuteCommand_DataSet1(currentCommand,dataConnection,databaseName,false);
				}
			}
			return ds;
		
		}
		
		private DataSet ExecuteCommand_DataSet1 (string command, IDbConnection dataConnection, string databaseName, bool IsQuery )
		{
			DataSet				dataSet = new DataSet();
			DataTable			dataTable = new DataTable();
			int length = command.Length;
			
			string tableName="Query";
			
			try 
			{	
				_currentCommand = new DB2Command(command, (DB2Connection)dataConnection);
				if(IsQuery)
				{
					DataAdapter= new DB2DataAdapter(_currentCommand);
					DB2CommandBuilder commandBuilder = new DB2CommandBuilder(_dataAdapter);
					_dataAdapter.Fill(dataSet,tableName);
					return dataSet;
				}
				else
				{
					_currentCommand.ExecuteNonQuery();
					return null;
				}
			}
			catch(Exception ex)
			{
				throw(ex);
			}
			return dataSet;
		
		}

		
		
		
		public string GetUpdateStatements(string command, IDbConnection dataConnection, string databaseName)
		{
			throw new QueryCommander.Database.MinorException(Localization.GetString("General.MethodNotImplemented"));
			return null;
		}

		public string GetInsertStatements(string command, IDbConnection dataConnection, string databaseName)
		{
			throw new QueryCommander.Database.MinorException(Localization.GetString("General.MethodNotImplemented"));
			return null;
		}

		public string GetXmlDoc(string DBName, IDbConnection dataConnection, string whereConditions)
		{
			throw new QueryCommander.Database.MinorException(Localization.GetString("General.MethodNotImplemented"));
			return null;
		}

		
		public string GetCreateTableString(string tableName, IDbConnection dataConnection, string databaseName)
		{
			throw new QueryCommander.Database.MinorException(Localization.GetString("General.MethodNotImplemented"));
			return null;
		}

		public string GetCreateJobString(string JobName, string DBName, IDbConnection dataConnection)
		{
			throw new Exception(Localization.GetString("General.MethodNotImplemented"));
		}

		/// <summary>
		/// Returns ALL database objects. Used to populate the Object browser
		/// </summary>
		/// <param name="ServerName"></param>
		/// <param name="dataConnection"></param>
		/// <returns></returns>
		public ArrayList GetDatabasesObjects(string ServerName, IDbConnection dataConnection)
		{
			ArrayList Result = new ArrayList();
			Hashtable schemas = new Hashtable();
			//DB db=new DB();
			
			// Get all schemas
			DataTable dsSchemas = ExecuteCommand(_commands.FindQueryProvider("GetAllSchemas"),dataConnection);

			foreach(DataRow dataBaseRow in dsSchemas.Rows)
			{
				DB db = new DB();
				db.Server = ServerName;
				db.Name = dataBaseRow["SchemaName"].ToString().Trim();
				schemas.Add(db.Name,db);
				Result.Add(db);
			}

			// Add Tables
			DataTable dsDatabasesObjects = ExecuteCommand(_commands.FindQueryProvider("GetAllObjects"),dataConnection);
			if(dsDatabasesObjects.Rows.Count==0)
				return null;

			foreach(DataRow dataBaseRow in dsDatabasesObjects.Rows)
			{
//				if(dataBaseRow["SchemaName"].ToString().Trim()!="WMMIHAA")
//					continue;
//				if(db.Server==null)
//				{
//					db = new DB();
//					db.Server = ServerName;
//					db.Name = dataBaseRow["SchemaName"].ToString();
//				}
				
				DBObject dbObject = new DBObject();
				dbObject.Name = dataBaseRow["ObjectName"].ToString();
				dbObject.Type = dataBaseRow["Type"].ToString();
				((DB)schemas[dataBaseRow["SchemaName"].ToString().Trim()]).dbObjects.Add(dbObject);
			}
			
			//Result.Add(db);

			return Result;
		}

		/// <summary>
		/// Returns all database objects matching [likeChar]. This method is used for IntelliSence
		/// </summary>
		/// <param name="DBName"></param>
		/// <param name="likeChar"></param>
		/// <param name="dataConnection"></param>
		/// <returns></returns>
		public ArrayList GetDatabasesObjects(string DBName, string likeChar, IDbConnection dataConnection)
		{
			//GetObjectsLike
			int dotPos = likeChar.IndexOf(".");
			string schemaName = "%";
			if(dotPos>0)
			{
				schemaName = likeChar.Substring(0,dotPos);
				likeChar = likeChar.Substring(dotPos+1);
			}
			likeChar = likeChar.Replace("*","%").ToUpper();
			string QueryString = _commands.GetTables(likeChar,schemaName);

			ArrayList		 Result = new ArrayList();
			DataTable dt = ExecuteCommand(QueryString,dataConnection);
			if(schemaName=="%")
				schemaName="";
			else
				schemaName+=".";

			foreach(DataRow row in dt.Rows)
			{
				DBObject dbObject = new DBObject();
				dbObject.Name = schemaName + row["ObjectName"].ToString();;
				dbObject.Type = row["Type"].ToString();
				Result.Add(dbObject);
			}
			return(Result);
		}
		/// <summary>
		/// Returns all columns for a given table or view
		/// </summary>
		/// <param name="DBName"></param>
		/// <param name="objectName"></param>
		/// <param name="dataConnection"></param>
		/// <returns></returns>
		public ArrayList GetDatabasesObjectProperties(string DBName, string objectName, IDbConnection dataConnection)
		{
			int dotPos = objectName.IndexOf(".");
			if(DBName.Length==0)
				DBName = "%";
			if(dotPos>0)
			{
				DBName = objectName.Substring(0,dotPos);
				objectName = objectName.Substring(dotPos+1);
			}

			string QueryString = _commands.GetColumnsFromTable(DBName,objectName);
			DataTable dt;
			ArrayList		 Result = new ArrayList();
			try
			{
				dt = ExecuteCommand(QueryString,dataConnection);
			}
			catch
			{
				return null;
			}

			foreach(DataRow row in dt.Rows)
			{
				DBObjectProperties dbObjectProperties = new DBObjectProperties();
				dbObjectProperties.Name = row["ColumnName"].ToString();
				Result.Add(dbObjectProperties);
			}
			return(Result);
		}

		public ArrayList GetDatabasesTriggers(string DBName, string objectName, IDbConnection dataConnection)
		{
			// TODO
			return null;
		}

		public ArrayList GetDataBaseUDTs(string DBName, IDbConnection dataConnection)
		{
			// TODO
			return null;
		}

		public ArrayList GetDataBaseDefaults(string DBName, IDbConnection dataConnection)
		{
			// TODO
			return null;
		}

		public ArrayList GetDataBaseRules(string DBName, IDbConnection dataConnection)
		{
			// TODO
			return null;
		}

		public ArrayList GetDatabaseIndexes(string DBName, string objectName, IDbConnection dataConnection)
		{
			//TODO
			return null;
		}

		public string GetCreateUDTString(DBObjectAttribute objUDT, string DBName, IDbConnection dataConnection)
		{
			// TODO
			return null;
		}

		public string GetCreateObjectString(string objectName, string DBName, IDbConnection dataConnection)
		{
			// TODO
			return null;
		}

		public ArrayList GetDatabasesReferencedObjects(string DBName, string likeChar, IDbConnection dataConnection)
		{
			throw new QueryCommander.Database.MinorException(Localization.GetString("General.MethodNotImplemented"));
			return null;
		}

		public ArrayList GetDatabasesReferencedObjectsClear(string DBName, string likeChar, IDbConnection dataConnection)
		{
			throw new QueryCommander.Database.MinorException(Localization.GetString("General.MethodNotImplemented"));
			return null;
		}

		public string GetObjectConstructorString(string DBName, string objectName, IDbConnection dataConnection, QueryCommander.Database.DBCommon.ScriptType scriptType, QueryCommander.Database.DBCommon.ScriptObjectType scriptObjectType)
		{
			string returnString = "";
			string QueryString;
			string schemaName="%";
			objectName=objectName.ToUpper();

			int dotPos = objectName.IndexOf(".");
			
			if(dotPos>0)
			{
				schemaName = objectName.Substring(0,dotPos);
				objectName = objectName.Substring(dotPos+1);
			}	
			
			if(scriptObjectType==DBCommon.ScriptObjectType.PROCEDURE)
				QueryString = _commands.GetRoutineDefinition(schemaName, objectName);
			else
				QueryString = _commands.GetTableDefinition(schemaName, objectName);

			DataTable dt = ExecuteCommand(QueryString,dataConnection);
			for(int i=0;i<dt.Rows.Count;i++)
				returnString += dt.Rows[i][0].ToString();  
			return returnString;
		}

		#endregion
	}
	
	class QueryCommands
	{
		XmlDocument _queryDocument=null;
		public QueryCommands(XmlDocument doc)
		{
			_queryDocument=doc;
		}

	
		public string  CreateScript(string objectName)
		{
			return String.Format(FindQueryProvider("GetTableConstructor"),objectName);
		}
		public string GetDatabases()
		{
			return FindQueryProvider("GetAllTables");
		}
		public string GetAllTables(string database)
		{
			return String.Format(FindQueryProvider("GetAllTables"),database);
		}

		public string GetTables(string tableLikeName,string schemaName)
		{
			return String.Format(FindQueryProvider("GetObjectsLike"),tableLikeName,schemaName);
		}
		public string GetColumnsFromTable(string schemaName, string tableName)
		{
			return String.Format(FindQueryProvider("GetColumnsFromTable"),schemaName,tableName);
		}
		public string GetTableConstructor(string tableName)
		{
			return String.Format(FindQueryProvider("GetTableConstructor"),tableName);
		}
		public string FindQueryProvider(string provider)
		{
			return _queryDocument.GetElementsByTagName(provider)[0].InnerText;
		}
			
		public string GetRoutineDefinition(string schemaName, string tableName)
		{
			return String.Format(FindQueryProvider("GetRoutineDefinition"),schemaName,tableName);
		}
		public string GetTableDefinition(string schemaName, string tableName)
		{
			return String.Format(FindQueryProvider("GetTableDefinition"),schemaName,tableName);
		}
	}
}
