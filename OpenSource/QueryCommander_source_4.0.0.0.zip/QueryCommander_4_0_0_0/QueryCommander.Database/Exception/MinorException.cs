using System;

namespace QueryCommander.Database
{
	/// <summary>
	/// Summary description for MinorException.
	/// </summary>
	public class MinorException : System.Exception
	{
		public MinorException ( string message ) : base ( message )
	{
	}

		
	}
}
