// *******************************************************************************
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// *******************************************************************************
using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using Oracle.DataAccess.Client;
using MySql.Data.MySqlClient;
//using Sybase.Data.AseClient;
using FirebirdSql.Data.Firebird;
using IBM.Data.DB2;


namespace QueryCommander.Database
{
	/// <summary>
	/// Summary description for DatabaseFactory.
	/// </summary>
	public abstract class DatabaseFactory
	{
		public static IDatabaseManager CreateNew(IDbConnection dataConnection)
		{
			if(dataConnection is SqlConnection)
				return new QueryCommander.Database.Microsoft.Sql2000.DataManager();
			else if(dataConnection is OleDbConnection)
				return new QueryCommander.Database.Microsoft.Sql2000.OleDbDataManager();
			else if(dataConnection is OracleConnection)
				return new QueryCommander.Database.Oracle._9i.DataManager();
			else if(dataConnection is MySqlConnection)
				return new QueryCommander.Database.MySQL._4x.DataManager();
//			else if(dataConnection is AseConnection)
//				return new QueryCommander.Database.Sybase.ASE.DataManager();
			else if(dataConnection is FbConnection)
				return new QueryCommander.Database.Firebird._2x.DataManager();
			else if(dataConnection is DB2Connection)
				return new QueryCommander.Database.IBM.DB2.DataManager();
			else
				return null;
		}
		public static IDbConnection GetConnection(string connectionType, string connectionString)
		{
			switch(connectionType)
			{
				case "System.Data.SqlClient.SqlConnection":
					return new SqlConnection(connectionString);
				case "System.Data.OleDb.OleDbConnection":
					return new OleDbConnection(connectionString);
				case "OracleConnection":
					return new OracleConnection(connectionString);
				case "MySqlConnection":
					return new MySqlConnection(connectionString);
				case "FbConnection":
					return new FbConnection(connectionString);
				case "DB2Connection":
					return new FbConnection(connectionString);
//				case "AseConnection":
//					return new AseConnection(connectionString);
			}
			return null;
		}
		public static IDbConnection GetConnection(DBConnectionType connectionType, string connectionString)
		{
			switch(connectionType)
			{
				case DBConnectionType.MicrosoftSqlClient:
					return new  SqlConnection(connectionString);
				case DBConnectionType.MicrosoftOleDb:
					return new OleDbConnection(connectionString);
				case DBConnectionType.OracleOleDb:
					return new OracleConnection(connectionString);
				case DBConnectionType.MySQL:
					return new MySqlConnection(connectionString);
//				case DBConnectionType.SybaseASE:
//					return new AseConnection(connectionString);
				case DBConnectionType.Firebird:
					return new FbConnection(connectionString);
				case DBConnectionType.DB2:
					return new DB2Connection(connectionString);
			}
			return null;
		}
		public static DBConnectionType GetConnectionType(IDbConnection connection)
		{
				if(connection is SqlConnection)
					return DBConnectionType.MicrosoftSqlClient;

				else if(connection is OleDbConnection)
					return DBConnectionType.MicrosoftOleDb;

				else if(connection is  OracleConnection)
					return DBConnectionType.OracleOleDb;

				else if(connection is  MySqlConnection)
					return DBConnectionType.MySQL;

//				else if(connection is  AseConnection)
//					return DBConnectionType.SybaseASE;

				else if(connection is  FbConnection)
					return DBConnectionType.Firebird;

				else if(connection is  DB2Connection)
					return DBConnectionType.DB2;
			
			return DBConnectionType.MicrosoftSqlClient;
		}
	
		public static int Update(IDataAdapter dataAdapter, DataTable dataTable)
		{
			if(dataAdapter is SqlDataAdapter)
				return ((SqlDataAdapter)dataAdapter).Update(dataTable); 
			else if(dataAdapter is MySqlDataAdapter)
				return ((MySqlDataAdapter)dataAdapter).Update(dataTable);
//			else if(dataAdapter is AseDataAdapter)
//				return ((AseDataAdapter)dataAdapter).Update(dataTable);
			else if(dataAdapter is OracleDataAdapter)
				return ((OracleDataAdapter)dataAdapter).Update(dataTable);
			else if(dataAdapter is FbDataAdapter)
				return ((FbDataAdapter)dataAdapter).Update(dataTable);
			else if(dataAdapter is DB2DataAdapter)
				return ((DB2DataAdapter)dataAdapter).Update(dataTable);

			return -1;
		
		}
		public static string ChangeDatabase(IDbConnection conn, string dbName)
		{
			if(conn is SqlConnection)
			{
				try{conn.ChangeDatabase(dbName);}
				catch
				{
					conn = new SqlConnection(conn.ConnectionString);
					conn.Open();
					conn.ChangeDatabase(dbName);
				}
				return "SQL";
			}
			else if(conn is MySqlConnection)
			{
				try{conn.ChangeDatabase(dbName);}
				catch
				{
					conn = new MySqlConnection(conn.ConnectionString);
					conn.Open();
					conn.ChangeDatabase(dbName);
				}
				return "SQL";
			}
//			else if(conn is AseConnection)
//			{
//				try{conn.ChangeDatabase(dbName);}
//				catch
//				{
//					conn = new AseConnection(conn.ConnectionString);
//					conn.Open();
//					conn.ChangeDatabase(dbName);
//				}
//				return "SQL";
//			}
			else if(conn is FbConnection)
			{
				try{conn.ChangeDatabase(dbName);}
				catch
				{
					conn = new FbConnection(conn.ConnectionString);
					conn.Open();
				}
				return "SQL";
			}
			else if(conn is DB2Connection)
			{
				try
				{
					QueryCommander.Database.IBM.DB2.DataManager dm = new QueryCommander.Database.IBM.DB2.DataManager();
					dm.ExecuteCommand("SET SCHEMA " + dbName,conn);
//					conn.ChangeDatabase(dbName);
				}
				catch
				{
					conn = new DB2Connection(conn.ConnectionString);
					conn.Open();
				}
				return "SQL";
			}
	
			else
			{
				return "ORACLESQL";
			}
		}
	}


}
