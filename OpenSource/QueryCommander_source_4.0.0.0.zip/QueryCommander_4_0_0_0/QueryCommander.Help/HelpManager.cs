using System;
using HtmlHelp;
using HtmlHelp.UIComponents;
using HtmlHelp.ChmDecoding;
using QueryCommander.Help.WinGui;

namespace QueryCommander.Help
{
	public class HelpManager
	{
//		FrmHelpBrowser _frmHelpBrowser = new FrmHelpBrowser();

		HtmlHelpSystem _reader =  new HtmlHelpSystem();
		DumpingInfo _dmpInfo=null;
		InfoTypeCategoryFilter _filter = new InfoTypeCategoryFilter();

		string _prefDumpOutput="";

		DumpCompression _prefDumpCompression = DumpCompression.Medium;

		DumpingFlags _prefDumpFlags = DumpingFlags.DumpBinaryTOC | DumpingFlags.DumpTextTOC | 
			DumpingFlags.DumpTextIndex | DumpingFlags.DumpBinaryIndex | 
			DumpingFlags.DumpUrlStr | DumpingFlags.DumpStrings;

		string _prefURLPrefix = "mk:@MSITStore:";
		bool _prefUseHH2TreePics = false;	

		public HelpManager(string fileName)
		{
			_reader.OpenFile( fileName, _dmpInfo );
		}
		public HtmlHelpSystem Reader
		{
			get
			{
				return _reader;
			}
		}
		
	}
}
