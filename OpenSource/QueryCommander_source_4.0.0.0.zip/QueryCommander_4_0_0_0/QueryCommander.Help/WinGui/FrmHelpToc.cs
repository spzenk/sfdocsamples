// *******************************************************************************
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// *******************************************************************************
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using QueryCommander.Help.WinGui.Base;
using HtmlHelp.UIComponents;

namespace QueryCommander.Help.WinGui
{
	/// <summary>
	/// Summary description for FrmHelpToc.
	/// </summary>
	public class FrmHelpToc : FrmBaseContent
	{
		#region Default
		public HtmlHelp.UIComponents.TocTree tocTree1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		private HelpManager _helpMamanger =null;
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.tocTree1 = new HtmlHelp.UIComponents.TocTree();
			this.SuspendLayout();
			// 
			// tocTree1
			// 
			this.tocTree1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tocTree1.DockPadding.All = 2;
			this.tocTree1.Location = new System.Drawing.Point(0, 0);
			this.tocTree1.Name = "tocTree1";
			this.tocTree1.Size = new System.Drawing.Size(292, 678);
			this.tocTree1.TabIndex = 0;
			this.tocTree1.TocSelected += new HtmlHelp.UIComponents.TocSelectedEventHandler(this.tocTree1_TocSelected);
			// 
			// FrmHelpToc
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 678);
			this.Controls.Add(this.tocTree1);
			this.Name = "FrmHelpToc";
			this.Text = "Help - Table of Contents";
			this.ResumeLayout(false);

		}
		#endregion
		#endregion
		
		FrmHelpBrowser _frmHelpBrowser = null;
		public FrmHelpToc(Form mdiParentForm, string fileName)
		{
			this.MdiParentForm=mdiParentForm;

			
			_helpMamanger=new QueryCommander.Help.HelpManager(fileName);
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			this.DockableAreas = ((WeifenLuo.WinFormsUI.DockAreas)(((WeifenLuo.WinFormsUI.DockAreas.DockLeft) 
				| WeifenLuo.WinFormsUI.DockAreas.DockRight)));
			

			InfoTypeCategoryFilter _filter = new InfoTypeCategoryFilter();

			// Build the table of contents tree view in the classlibrary control
			this.tocTree1.BuildTOC( _helpMamanger.Reader.TableOfContents, _filter );
		}

		
		#region Methods
		public void NavigateBrowser(string url)
		{
			object flags = 0;
			object targetFrame = String.Empty;
			object postData = String.Empty;
			object headers = String.Empty;
			object oUrl = url;

			if(_frmHelpBrowser==null || _frmHelpBrowser.IsDisposed)
				_frmHelpBrowser=new FrmHelpBrowser(this.MdiParent);

			_frmHelpBrowser.Show(this.DockPanel);
			_frmHelpBrowser.axWebBrowser1.Navigate2(ref oUrl, ref flags, ref targetFrame, ref postData, ref headers);
			
		}

		#endregion
		#region Events
		private void tocTree1_TocSelected(object sender, HtmlHelp.UIComponents.TocEventArgs e)
		{
			if( e.Item.Local.Length > 0)
			{
				NavigateBrowser(e.Item.Url);
			}
			
		}
		#endregion
	}
}
