// *******************************************************************************
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
// *******************************************************************************
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using QueryCommander.Help.WinGui.Base;
using HtmlHelp;
using HtmlHelp.UIComponents;

namespace QueryCommander.Help.WinGui
{
	/// <summary>
	/// Summary description for FrmHelpIndex.
	/// </summary>
	public class FrmHelpIndex  : FrmBaseContent
	{
		#region Private members
		FrmHelpBrowser _frmHelpBrowser = null;
		private HelpManager _helpMamanger =null;
		InfoTypeCategoryFilter _filter = new InfoTypeCategoryFilter();
		#endregion
		public HtmlHelp.UIComponents.helpIndex helpIndex1;
		#region Default

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.helpIndex1 = new HtmlHelp.UIComponents.helpIndex();
			this.SuspendLayout();
			// 
			// helpIndex1
			// 
			this.helpIndex1.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.helpIndex1.Location = new System.Drawing.Point(0, 0);
			this.helpIndex1.Name = "helpIndex1";
			this.helpIndex1.Size = new System.Drawing.Size(292, 416);
			this.helpIndex1.TabIndex = 0;
			this.helpIndex1.IndexSelected += new HtmlHelp.UIComponents.IndexSelectedEventHandler(this.helpIndex1_IndexSelected);
			// 
			// FrmHelpIndex
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 798);
			this.Controls.Add(this.helpIndex1);
			this.Name = "FrmHelpIndex";
			this.Text = "Help - Index";
			this.SizeChanged += new System.EventHandler(this.FrmHelpIndex_SizeChanged);
			this.ResumeLayout(false);

		}
		#endregion

		#endregion
		public FrmHelpIndex(Form mdiParentForm, string fileName)
		{
			this.MdiParentForm=mdiParentForm;
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			this.DockableAreas = ((WeifenLuo.WinFormsUI.DockAreas)(((WeifenLuo.WinFormsUI.DockAreas.DockLeft) 
				| WeifenLuo.WinFormsUI.DockAreas.DockRight)));

			_helpMamanger=new QueryCommander.Help.HelpManager(fileName);

			InitHelp();

		}
		
		public void InitHelp()
		{
			helpIndex1.ClearContents();
			helpIndex1.Enabled = _helpMamanger.Reader.HasIndex;
			
			

			if( _helpMamanger.Reader.HasKLinks )
				helpIndex1.BuildIndex( _helpMamanger.Reader.Index, IndexType.KeywordLinks, _filter );
			else if( _helpMamanger.Reader.HasALinks )
				helpIndex1.BuildIndex( _helpMamanger.Reader.Index, IndexType.AssiciativeLinks, _filter );
			
			GC.Collect();
		
		}

		private void helpIndex1_IndexSelected(object sender, HtmlHelp.UIComponents.IndexEventArgs e)
		{
			string c0 = new System.Diagnostics.StackTrace().GetFrame(0).GetMethod().Name;
			string c1 = new System.Diagnostics.StackTrace().GetFrame(1).GetMethod().Name;
			string c2 = new System.Diagnostics.StackTrace().GetFrame(2).GetMethod().Name;
			string c3 = new System.Diagnostics.StackTrace().GetFrame(3).GetMethod().Name;
			string c4 = new System.Diagnostics.StackTrace().GetFrame(4).GetMethod().Name;
			string c5 = new System.Diagnostics.StackTrace().GetFrame(5).GetMethod().Name;
			string c6 = new System.Diagnostics.StackTrace().GetFrame(6).GetMethod().Name;
			string c7 = new System.Diagnostics.StackTrace().GetFrame(7).GetMethod().Name;
			string c8 = new System.Diagnostics.StackTrace().GetFrame(8).GetMethod().Name;
			string c9 = new System.Diagnostics.StackTrace().GetFrame(9).GetMethod().Name;

			//if(this.IsActivated)
				NavigateBrowser(e.URL);
		}
		public void NavigateBrowser(string url)
		{
			object flags = 0;
			object targetFrame = String.Empty;
			object postData = String.Empty;
			object headers = String.Empty;
			object oUrl = url;

			if(_frmHelpBrowser==null || _frmHelpBrowser.IsDisposed)
				_frmHelpBrowser=new FrmHelpBrowser(this.MdiParent);

			_frmHelpBrowser.Show(this.DockPanel);
			_frmHelpBrowser.axWebBrowser1.Navigate2(ref oUrl, ref flags, ref targetFrame, ref postData, ref headers);
			
		}
		public void SearchWord(string word)
		{
			this.helpIndex1.SelectText(word);
		}

		private void FrmHelpIndex_SizeChanged(object sender, System.EventArgs e)
		{
			helpIndex1.Size = this.Size;
			helpIndex1.Location = new Point(0,0);
		}
	}
}
