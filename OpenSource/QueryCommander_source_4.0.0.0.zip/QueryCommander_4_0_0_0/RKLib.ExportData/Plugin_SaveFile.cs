using System;
using System.IO;
using System.Text;
using System.Data;
using System.Windows.Forms;
using QueryCommander.PlugIn.Core;
using QueryCommander.PlugIn.Core.Interfaces;
using RKLib.ExportData;

namespace ExcelFileOutput
{/// <summary>
	/// Summary description for Plugin_SaveFile.
	/// </summary>
	public class Plugin_SaveFile :IPlugin_OnAfterQueryExecution1
	{
		#region IPlugin_OnAfterQueryExecution1 Members

		/// <summary>
		/// Calling this method will save the result (callcontext.ResultDataSet) to a textfile.
		/// </summary>
		/// <param name="callcontext"></param>
		/// <param name="handle"></param>
		/// <param name="plugInVariables"></param>
		/// <param name="menuItem">Current menu item</param>
		/// <returns></returns>
		public object Execute(CallContext callcontext, System.IntPtr handle, System.Collections.Hashtable plugInVariables)
		{
			Guid id = new Guid("{55FBDF53-1BD4-4477-8382-1D7290D9ABBF}");
			if( Convert.ToBoolean( plugInVariables[id] )==true)
			{
				SaveFile(callcontext.ResultDataSet,callcontext.QueryWindowContext);
			}
			

			return null;
		}

		public Common.ExecutionTypes ExecutionType
		{
			get
			{
				// There are no return values
				return Common.ExecutionTypes.None;
			}
		}

		#endregion

		/// <summary>
		/// Creates and saves the text-file
		/// </summary>
		/// <param name="ds"></param>
		/// <param name="query"></param>
		private void SaveFile(DataSet ds, string query)
		{
			SaveFileDialog saveFileDialog = new SaveFileDialog();

			saveFileDialog.FileName ="QueryCommander_Export.xls";
			saveFileDialog.Filter = "Excel files (*.xls)|*.xls|All files (*.*)|*.*" ;

			if(saveFileDialog.ShowDialog() == DialogResult.OK)
			{
				Export export = new Export("Win");
				if (ds.Tables.Count > 1)
					export.ExportDetails(ds.Tables,Export.ExportFormat.Excel,saveFileDialog.FileName);
				else
					export.ExportDetails(ds.Tables[0],Export.ExportFormat.Excel,saveFileDialog.FileName);				
			}
		}
	}
}
