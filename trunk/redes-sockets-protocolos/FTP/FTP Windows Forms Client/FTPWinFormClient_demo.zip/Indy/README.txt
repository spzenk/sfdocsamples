Here are the instructions:
Please extract this zip file in any directory, let us assume, it is "D:\"


IF YOU HAVE VISUAL STUDIO.NET
THEN

 1. Copy "Indy.Sockets.dll" downloaded from
http://www.indyproject.org/downloads/10/IndyNetCore.zip in
"D:\Indy\bin\Debug"
  2. Open the Visual Studio.Net. File/Open/Project, browse to "D:\Indy";
double click "Indy.sln"
  3. Press F5 to start
 
 ELSE IF YOU JUST HAVE .NET FRAMEWORK 1.1 INSTALL
  
   1. Copy "Indy.Sockets.dll" downloaded from http://www.indyproject.org/downloads/10/IndyNetCore.zip in "D:\Indy"
   2. Change Directory to "D:\Indy" and, 
   3. Issue nmake command to build "IndyFTP.exe" e.g. "D:\Indy>nmake". It would start the programs
 
 END IF

 
  4.. Enter FTP Server name, user id, and password
  5.. Click "Login", it would go to the server, and display a list of
directories in the list box
  6.. Double clicking on any directory would take you to that directory,
refreshing the listing
  7.. Clicking on the "^" button would take you [back to] the parent
directory refreshing the list
  8.. Double clicking on any file would prepare that file for download into
current working directory
  9.. Clicking the "DOWNLOAD" button would start the transfer. It would be
invisible once download starts. The status bar would show the current file
being downloaded
  10.. Entering another FTP site name and clicking "Login" would log you off
from current site, login to new site
  11.. Closing the form would log you off the FTP server before exiting

