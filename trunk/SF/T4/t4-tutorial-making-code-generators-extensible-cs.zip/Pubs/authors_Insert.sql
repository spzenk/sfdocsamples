create procedure authors_Insert
	@au_id id,
	@au_lname varchar,
	@au_fname varchar,
	@phone char,
	@address varchar,
	@city varchar,
	@state char,
	@zip char,
	@contract bit
as
    insert into authors
    (
		au_id,
		au_lname,
		au_fname,
		phone,
		address,
		city,
		state,
		zip,
		contract
    )
    values
    (
		@au_id,
		@au_lname,
		@au_fname,
		@phone,
		@address,
		@city,
		@state,
		@zip,
		@contract
    )
