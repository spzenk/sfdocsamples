create procedure titleauthor_Delete
	@au_id id
	@title_id tid
as
    delete from titleauthor
    where
		au_id = @au_id
		title_id = @title_id
