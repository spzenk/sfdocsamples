create procedure jobs_Update
	@job_id smallint,
	@job_desc varchar,
	@min_lvl tinyint,
	@max_lvl tinyint
as
    update jobs
    set
		job_desc = @job_desc,
		min_lvl = @min_lvl,
		max_lvl = @max_lvl
    where
		job_id = @job_id
