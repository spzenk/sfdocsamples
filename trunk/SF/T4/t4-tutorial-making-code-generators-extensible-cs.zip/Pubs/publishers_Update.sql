create procedure publishers_Update
	@pub_id char,
	@pub_name varchar,
	@city varchar,
	@state char,
	@country varchar
as
    update publishers
    set
		pub_name = @pub_name,
		city = @city,
		state = @state,
		country = @country
    where
		pub_id = @pub_id
