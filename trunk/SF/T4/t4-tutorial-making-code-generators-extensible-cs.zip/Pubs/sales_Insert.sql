create procedure sales_Insert
	@stor_id char,
	@ord_num varchar,
	@ord_date datetime,
	@qty smallint,
	@payterms varchar,
	@title_id tid
as
    insert into sales
    (
		stor_id,
		ord_num,
		ord_date,
		qty,
		payterms,
		title_id
    )
    values
    (
		@stor_id,
		@ord_num,
		@ord_date,
		@qty,
		@payterms,
		@title_id
    )
