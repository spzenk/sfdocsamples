create procedure authors_Update
	@au_id id,
	@au_lname varchar,
	@au_fname varchar,
	@phone char,
	@address varchar,
	@city varchar,
	@state char,
	@zip char,
	@contract bit
as
    update authors
    set
		au_lname = @au_lname,
		au_fname = @au_fname,
		phone = @phone,
		address = @address,
		city = @city,
		state = @state,
		zip = @zip,
		contract = @contract
    where
		au_id = @au_id
