create procedure sales_Update
	@stor_id char,
	@ord_num varchar,
	@ord_date datetime,
	@qty smallint,
	@payterms varchar,
	@title_id tid
as
    update sales
    set
		ord_date = @ord_date,
		qty = @qty,
		payterms = @payterms,
    where
		stor_id = @stor_id
		ord_num = @ord_num
		title_id = @title_id
