create procedure publishers_Delete
	@pub_id char
as
    delete from publishers
    where
		pub_id = @pub_id
