create procedure publishers_Insert
	@pub_id char,
	@pub_name varchar,
	@city varchar,
	@state char,
	@country varchar
as
    insert into publishers
    (
		pub_id,
		pub_name,
		city,
		state,
		country
    )
    values
    (
		@pub_id,
		@pub_name,
		@city,
		@state,
		@country
    )
