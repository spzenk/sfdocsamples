create procedure employee_Update
	@emp_id empid,
	@fname varchar,
	@minit char,
	@lname varchar,
	@job_id smallint,
	@job_lvl tinyint,
	@pub_id char,
	@hire_date datetime
as
    update employee
    set
		fname = @fname,
		minit = @minit,
		lname = @lname,
		job_id = @job_id,
		job_lvl = @job_lvl,
		pub_id = @pub_id,
		hire_date = @hire_date
    where
		emp_id = @emp_id
