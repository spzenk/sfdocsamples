create procedure pub_info_Insert
	@pub_id char,
	@logo image,
	@pr_info text
as
    insert into pub_info
    (
		pub_id,
		logo,
		pr_info
    )
    values
    (
		@pub_id,
		@logo,
		@pr_info
    )
