create procedure jobs_Delete
	@job_id smallint
as
    delete from jobs
    where
		job_id = @job_id
