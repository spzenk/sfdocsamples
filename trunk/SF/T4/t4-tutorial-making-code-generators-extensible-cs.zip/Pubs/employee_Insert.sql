create procedure employee_Insert
	@emp_id empid,
	@fname varchar,
	@minit char,
	@lname varchar,
	@job_id smallint,
	@job_lvl tinyint,
	@pub_id char,
	@hire_date datetime
as
    insert into employee
    (
		emp_id,
		fname,
		minit,
		lname,
		job_id,
		job_lvl,
		pub_id,
		hire_date
    )
    values
    (
		@emp_id,
		@fname,
		@minit,
		@lname,
		@job_id,
		@job_lvl,
		@pub_id,
		@hire_date
    )
