create procedure titles_Insert
	@title_id tid,
	@title varchar,
	@type char,
	@pub_id char,
	@price money,
	@advance money,
	@royalty int,
	@ytd_sales int,
	@notes varchar,
	@pubdate datetime
as
    insert into titles
    (
		title_id,
		title,
		type,
		pub_id,
		price,
		advance,
		royalty,
		ytd_sales,
		notes,
		pubdate
    )
    values
    (
		@title_id,
		@title,
		@type,
		@pub_id,
		@price,
		@advance,
		@royalty,
		@ytd_sales,
		@notes,
		@pubdate
    )
