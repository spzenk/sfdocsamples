create procedure stores_Update
	@stor_id char,
	@stor_name varchar,
	@stor_address varchar,
	@city varchar,
	@state char,
	@zip char
as
    update stores
    set
		stor_name = @stor_name,
		stor_address = @stor_address,
		city = @city,
		state = @state,
		zip = @zip
    where
		stor_id = @stor_id
