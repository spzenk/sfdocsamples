create procedure titles_Delete
	@title_id tid
as
    delete from titles
    where
		title_id = @title_id
