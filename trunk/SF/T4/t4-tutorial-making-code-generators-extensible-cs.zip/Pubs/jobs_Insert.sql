create procedure jobs_Insert
	@job_id smallint,
	@job_desc varchar,
	@min_lvl tinyint,
	@max_lvl tinyint
as
    insert into jobs
    (
		job_id,
		job_desc,
		min_lvl,
		max_lvl
    )
    values
    (
		@job_id,
		@job_desc,
		@min_lvl,
		@max_lvl
    )
