create procedure titleauthor_Insert
	@au_id id,
	@title_id tid,
	@au_ord tinyint,
	@royaltyper int
as
    insert into titleauthor
    (
		au_id,
		title_id,
		au_ord,
		royaltyper
    )
    values
    (
		@au_id,
		@title_id,
		@au_ord,
		@royaltyper
    )
