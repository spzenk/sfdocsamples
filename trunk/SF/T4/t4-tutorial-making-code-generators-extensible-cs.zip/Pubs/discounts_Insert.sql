create procedure discounts_Insert
	@discounttype varchar,
	@stor_id char,
	@lowqty smallint,
	@highqty smallint,
	@discount decimal
as
    insert into discounts
    (
		discounttype,
		stor_id,
		lowqty,
		highqty,
		discount
    )
    values
    (
		@discounttype,
		@stor_id,
		@lowqty,
		@highqty,
		@discount
    )
