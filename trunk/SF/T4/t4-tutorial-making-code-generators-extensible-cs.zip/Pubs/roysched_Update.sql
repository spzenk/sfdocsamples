create procedure roysched_Update
	@title_id tid,
	@lorange int,
	@hirange int,
	@royalty int
as
    update roysched
    set
		title_id = @title_id,
		lorange = @lorange,
		hirange = @hirange,
		royalty = @royalty
    where
