create procedure titles_Update
	@title_id tid,
	@title varchar,
	@type char,
	@pub_id char,
	@price money,
	@advance money,
	@royalty int,
	@ytd_sales int,
	@notes varchar,
	@pubdate datetime
as
    update titles
    set
		title = @title,
		type = @type,
		pub_id = @pub_id,
		price = @price,
		advance = @advance,
		royalty = @royalty,
		ytd_sales = @ytd_sales,
		notes = @notes,
		pubdate = @pubdate
    where
		title_id = @title_id
