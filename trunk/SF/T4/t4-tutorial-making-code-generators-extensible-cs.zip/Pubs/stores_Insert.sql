create procedure stores_Insert
	@stor_id char,
	@stor_name varchar,
	@stor_address varchar,
	@city varchar,
	@state char,
	@zip char
as
    insert into stores
    (
		stor_id,
		stor_name,
		stor_address,
		city,
		state,
		zip
    )
    values
    (
		@stor_id,
		@stor_name,
		@stor_address,
		@city,
		@state,
		@zip
    )
