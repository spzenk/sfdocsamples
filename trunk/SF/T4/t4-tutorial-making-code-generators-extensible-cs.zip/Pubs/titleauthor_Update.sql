create procedure titleauthor_Update
	@au_id id,
	@title_id tid,
	@au_ord tinyint,
	@royaltyper int
as
    update titleauthor
    set
		au_ord = @au_ord,
		royaltyper = @royaltyper
    where
		au_id = @au_id
		title_id = @title_id
