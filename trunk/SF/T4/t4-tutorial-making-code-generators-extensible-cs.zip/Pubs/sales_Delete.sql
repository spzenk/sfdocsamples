create procedure sales_Delete
	@stor_id char
	@ord_num varchar
	@title_id tid
as
    delete from sales
    where
		stor_id = @stor_id
		ord_num = @ord_num
		title_id = @title_id
