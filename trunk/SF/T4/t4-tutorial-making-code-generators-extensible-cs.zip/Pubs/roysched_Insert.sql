create procedure roysched_Insert
	@title_id tid,
	@lorange int,
	@hirange int,
	@royalty int
as
    insert into roysched
    (
		title_id,
		lorange,
		hirange,
		royalty
    )
    values
    (
		@title_id,
		@lorange,
		@hirange,
		@royalty
    )
