create procedure discounts_Update
	@discounttype varchar,
	@stor_id char,
	@lowqty smallint,
	@highqty smallint,
	@discount decimal
as
    update discounts
    set
		discounttype = @discounttype,
		stor_id = @stor_id,
		lowqty = @lowqty,
		highqty = @highqty,
		discount = @discount
    where
