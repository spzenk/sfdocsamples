create procedure discounts_Delete
as
    delete from discounts
    where
