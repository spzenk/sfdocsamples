create procedure employee_Delete
	@emp_id empid
as
    delete from employee
    where
		emp_id = @emp_id
