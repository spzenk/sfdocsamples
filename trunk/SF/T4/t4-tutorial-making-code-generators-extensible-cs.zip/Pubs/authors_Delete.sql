create procedure authors_Delete
	@au_id id
as
    delete from authors
    where
		au_id = @au_id
