create procedure pub_info_Delete
	@pub_id char
as
    delete from pub_info
    where
		pub_id = @pub_id
