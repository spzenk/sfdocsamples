create procedure pub_info_Update
	@pub_id char,
	@logo image,
	@pr_info text
as
    update pub_info
    set
		logo = @logo,
		pr_info = @pr_info
    where
		pub_id = @pub_id
