create procedure roysched_Delete
as
    delete from roysched
    where
