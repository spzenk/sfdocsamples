create procedure stores_Delete
	@stor_id char
as
    delete from stores
    where
		stor_id = @stor_id
