if  exists (select * from sys.objects 
            where object_id = object_id('Orders_Delete')
              and type in ('P', 'PC'))
    drop procedure Orders_Delete
go
create procedure Orders_Delete
	@OrderID int
as
    delete from Orders
    where
		OrderID = @OrderID
