if  exists (select * from sys.objects 
            where object_id = object_id('Region_Delete')
              and type in ('P', 'PC'))
    drop procedure Region_Delete
go
create procedure Region_Delete
	@RegionID int
as
    delete from Region
    where
		RegionID = @RegionID
