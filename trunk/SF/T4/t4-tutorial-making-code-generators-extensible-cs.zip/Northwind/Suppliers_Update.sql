if  exists (select * from sys.objects 
            where object_id = object_id('Suppliers_Update')
              and type in ('P', 'PC'))
    drop procedure Suppliers_Update
go
create procedure Suppliers_Update
	@SupplierID int,
	@CompanyName nvarchar,
	@ContactName nvarchar,
	@ContactTitle nvarchar,
	@Address nvarchar,
	@City nvarchar,
	@Region nvarchar,
	@PostalCode nvarchar,
	@Country nvarchar,
	@Phone nvarchar,
	@Fax nvarchar,
	@HomePage ntext
as
    update Suppliers
    set
		CompanyName = @CompanyName,
		ContactName = @ContactName,
		ContactTitle = @ContactTitle,
		Address = @Address,
		City = @City,
		Region = @Region,
		PostalCode = @PostalCode,
		Country = @Country,
		Phone = @Phone,
		Fax = @Fax,
		HomePage = @HomePage
    where
		SupplierID = @SupplierID
