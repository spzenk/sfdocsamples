if  exists (select * from sys.objects 
            where object_id = object_id('Employees_Update')
              and type in ('P', 'PC'))
    drop procedure Employees_Update
go
create procedure Employees_Update
	@EmployeeID int,
	@LastName nvarchar,
	@FirstName nvarchar,
	@Title nvarchar,
	@TitleOfCourtesy nvarchar,
	@BirthDate datetime,
	@HireDate datetime,
	@Address nvarchar,
	@City nvarchar,
	@Region nvarchar,
	@PostalCode nvarchar,
	@Country nvarchar,
	@HomePhone nvarchar,
	@Extension nvarchar,
	@Photo image,
	@Notes ntext,
	@ReportsTo int,
	@PhotoPath nvarchar
as
    update Employees
    set
		LastName = @LastName,
		FirstName = @FirstName,
		Title = @Title,
		TitleOfCourtesy = @TitleOfCourtesy,
		BirthDate = @BirthDate,
		HireDate = @HireDate,
		Address = @Address,
		City = @City,
		Region = @Region,
		PostalCode = @PostalCode,
		Country = @Country,
		HomePhone = @HomePhone,
		Extension = @Extension,
		Photo = @Photo,
		Notes = @Notes,
		ReportsTo = @ReportsTo,
		PhotoPath = @PhotoPath
    where
		EmployeeID = @EmployeeID
