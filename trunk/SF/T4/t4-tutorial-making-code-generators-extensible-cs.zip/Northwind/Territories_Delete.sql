if  exists (select * from sys.objects 
            where object_id = object_id('Territories_Delete')
              and type in ('P', 'PC'))
    drop procedure Territories_Delete
go
create procedure Territories_Delete
	@TerritoryID nvarchar
as
    delete from Territories
    where
		TerritoryID = @TerritoryID
