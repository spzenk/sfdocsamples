if  exists (select * from sys.objects 
            where object_id = object_id('Territories_Insert')
              and type in ('P', 'PC'))
    drop procedure Territories_Insert
go
create procedure Territories_Insert
	@TerritoryID nvarchar,
	@TerritoryDescription nchar,
	@RegionID int
as
    insert into Territories
    (
		TerritoryID,
		TerritoryDescription,
		RegionID
    )
    values
    (
		@TerritoryID,
		@TerritoryDescription,
		@RegionID
    )
