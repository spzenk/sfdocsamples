if  exists (select * from sys.objects 
            where object_id = object_id('EmployeeTerritories_Delete')
              and type in ('P', 'PC'))
    drop procedure EmployeeTerritories_Delete
go
create procedure EmployeeTerritories_Delete
	@EmployeeID int
	@TerritoryID nvarchar
as
    delete from EmployeeTerritories
    where
		EmployeeID = @EmployeeID
		TerritoryID = @TerritoryID
