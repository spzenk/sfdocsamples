if  exists (select * from sys.objects 
            where object_id = object_id('Employees_Insert')
              and type in ('P', 'PC'))
    drop procedure Employees_Insert
go
create procedure Employees_Insert
	@EmployeeID int,
	@LastName nvarchar,
	@FirstName nvarchar,
	@Title nvarchar,
	@TitleOfCourtesy nvarchar,
	@BirthDate datetime,
	@HireDate datetime,
	@Address nvarchar,
	@City nvarchar,
	@Region nvarchar,
	@PostalCode nvarchar,
	@Country nvarchar,
	@HomePhone nvarchar,
	@Extension nvarchar,
	@Photo image,
	@Notes ntext,
	@ReportsTo int,
	@PhotoPath nvarchar
as
    insert into Employees
    (
		EmployeeID,
		LastName,
		FirstName,
		Title,
		TitleOfCourtesy,
		BirthDate,
		HireDate,
		Address,
		City,
		Region,
		PostalCode,
		Country,
		HomePhone,
		Extension,
		Photo,
		Notes,
		ReportsTo,
		PhotoPath
    )
    values
    (
		@EmployeeID,
		@LastName,
		@FirstName,
		@Title,
		@TitleOfCourtesy,
		@BirthDate,
		@HireDate,
		@Address,
		@City,
		@Region,
		@PostalCode,
		@Country,
		@HomePhone,
		@Extension,
		@Photo,
		@Notes,
		@ReportsTo,
		@PhotoPath
    )
