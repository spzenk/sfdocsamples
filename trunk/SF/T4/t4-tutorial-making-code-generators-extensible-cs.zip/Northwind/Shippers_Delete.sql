if  exists (select * from sys.objects 
            where object_id = object_id('Shippers_Delete')
              and type in ('P', 'PC'))
    drop procedure Shippers_Delete
go
create procedure Shippers_Delete
	@ShipperID int
as
    delete from Shippers
    where
		ShipperID = @ShipperID
