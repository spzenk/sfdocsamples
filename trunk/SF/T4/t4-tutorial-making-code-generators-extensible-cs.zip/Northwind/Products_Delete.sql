if  exists (select * from sys.objects 
            where object_id = object_id('Products_Delete')
              and type in ('P', 'PC'))
    drop procedure Products_Delete
go
create procedure Products_Delete
	@ProductID int
as
    delete from Products
    where
		ProductID = @ProductID
