if  exists (select * from sys.objects 
            where object_id = object_id('Customers_Insert')
              and type in ('P', 'PC'))
    drop procedure Customers_Insert
go
create procedure Customers_Insert
	@CustomerID nchar,
	@CompanyName nvarchar,
	@ContactName nvarchar,
	@ContactTitle nvarchar,
	@Address nvarchar,
	@City nvarchar,
	@Region nvarchar,
	@PostalCode nvarchar,
	@Country nvarchar,
	@Phone nvarchar,
	@Fax nvarchar
as
    insert into Customers
    (
		CustomerID,
		CompanyName,
		ContactName,
		ContactTitle,
		Address,
		City,
		Region,
		PostalCode,
		Country,
		Phone,
		Fax
    )
    values
    (
		@CustomerID,
		@CompanyName,
		@ContactName,
		@ContactTitle,
		@Address,
		@City,
		@Region,
		@PostalCode,
		@Country,
		@Phone,
		@Fax
    )
