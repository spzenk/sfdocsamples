if  exists (select * from sys.objects 
            where object_id = object_id('Orders_Insert')
              and type in ('P', 'PC'))
    drop procedure Orders_Insert
go
create procedure Orders_Insert
	@OrderID int,
	@CustomerID nchar,
	@EmployeeID int,
	@OrderDate datetime,
	@RequiredDate datetime,
	@ShippedDate datetime,
	@ShipVia int,
	@Freight money,
	@ShipName nvarchar,
	@ShipAddress nvarchar,
	@ShipCity nvarchar,
	@ShipRegion nvarchar,
	@ShipPostalCode nvarchar,
	@ShipCountry nvarchar
as
    insert into Orders
    (
		OrderID,
		CustomerID,
		EmployeeID,
		OrderDate,
		RequiredDate,
		ShippedDate,
		ShipVia,
		Freight,
		ShipName,
		ShipAddress,
		ShipCity,
		ShipRegion,
		ShipPostalCode,
		ShipCountry
    )
    values
    (
		@OrderID,
		@CustomerID,
		@EmployeeID,
		@OrderDate,
		@RequiredDate,
		@ShippedDate,
		@ShipVia,
		@Freight,
		@ShipName,
		@ShipAddress,
		@ShipCity,
		@ShipRegion,
		@ShipPostalCode,
		@ShipCountry
    )
