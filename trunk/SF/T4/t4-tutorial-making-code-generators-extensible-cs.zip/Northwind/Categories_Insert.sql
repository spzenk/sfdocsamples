if  exists (select * from sys.objects 
            where object_id = object_id('Categories_Insert')
              and type in ('P', 'PC'))
    drop procedure Categories_Insert
go
create procedure Categories_Insert
	@CategoryID int,
	@CategoryName nvarchar,
	@Description ntext,
	@Picture image
as
    insert into Categories
    (
		CategoryID,
		CategoryName,
		Description,
		Picture
    )
    values
    (
		@CategoryID,
		@CategoryName,
		@Description,
		@Picture
    )
