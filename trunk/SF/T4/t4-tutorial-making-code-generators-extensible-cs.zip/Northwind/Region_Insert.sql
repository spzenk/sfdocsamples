if  exists (select * from sys.objects 
            where object_id = object_id('Region_Insert')
              and type in ('P', 'PC'))
    drop procedure Region_Insert
go
create procedure Region_Insert
	@RegionID int,
	@RegionDescription nchar
as
    insert into Region
    (
		RegionID,
		RegionDescription
    )
    values
    (
		@RegionID,
		@RegionDescription
    )
