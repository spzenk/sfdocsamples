if  exists (select * from sys.objects 
            where object_id = object_id('CustomerDemographics_Update')
              and type in ('P', 'PC'))
    drop procedure CustomerDemographics_Update
go
create procedure CustomerDemographics_Update
	@CustomerTypeID nchar,
	@CustomerDesc ntext
as
    update CustomerDemographics
    set
		CustomerDesc = @CustomerDesc
    where
		CustomerTypeID = @CustomerTypeID
