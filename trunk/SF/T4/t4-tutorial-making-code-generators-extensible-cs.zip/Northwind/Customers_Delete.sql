if  exists (select * from sys.objects 
            where object_id = object_id('Customers_Delete')
              and type in ('P', 'PC'))
    drop procedure Customers_Delete
go
create procedure Customers_Delete
	@CustomerID nchar
as
    delete from Customers
    where
		CustomerID = @CustomerID
