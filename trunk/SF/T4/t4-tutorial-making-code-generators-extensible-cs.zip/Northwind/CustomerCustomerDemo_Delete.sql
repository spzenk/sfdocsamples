if  exists (select * from sys.objects 
            where object_id = object_id('CustomerCustomerDemo_Delete')
              and type in ('P', 'PC'))
    drop procedure CustomerCustomerDemo_Delete
go
create procedure CustomerCustomerDemo_Delete
	@CustomerID nchar
	@CustomerTypeID nchar
as
    delete from CustomerCustomerDemo
    where
		CustomerID = @CustomerID
		CustomerTypeID = @CustomerTypeID
