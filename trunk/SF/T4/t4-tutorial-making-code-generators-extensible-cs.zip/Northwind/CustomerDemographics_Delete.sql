if  exists (select * from sys.objects 
            where object_id = object_id('CustomerDemographics_Delete')
              and type in ('P', 'PC'))
    drop procedure CustomerDemographics_Delete
go
create procedure CustomerDemographics_Delete
	@CustomerTypeID nchar
as
    delete from CustomerDemographics
    where
		CustomerTypeID = @CustomerTypeID
