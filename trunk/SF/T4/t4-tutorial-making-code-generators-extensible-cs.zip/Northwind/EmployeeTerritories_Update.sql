if  exists (select * from sys.objects 
            where object_id = object_id('EmployeeTerritories_Update')
              and type in ('P', 'PC'))
    drop procedure EmployeeTerritories_Update
go
create procedure EmployeeTerritories_Update
	@EmployeeID int,
	@TerritoryID nvarchar
as
    update EmployeeTerritories
    set
    where
		EmployeeID = @EmployeeID
		TerritoryID = @TerritoryID
