if  exists (select * from sys.objects 
            where object_id = object_id('Order Details_Delete')
              and type in ('P', 'PC'))
    drop procedure Order Details_Delete
go
create procedure Order Details_Delete
	@OrderID int
	@ProductID int
as
    delete from Order Details
    where
		OrderID = @OrderID
		ProductID = @ProductID
