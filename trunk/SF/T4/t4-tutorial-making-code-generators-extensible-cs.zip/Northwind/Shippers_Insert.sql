if  exists (select * from sys.objects 
            where object_id = object_id('Shippers_Insert')
              and type in ('P', 'PC'))
    drop procedure Shippers_Insert
go
create procedure Shippers_Insert
	@ShipperID int,
	@CompanyName nvarchar,
	@Phone nvarchar
as
    insert into Shippers
    (
		ShipperID,
		CompanyName,
		Phone
    )
    values
    (
		@ShipperID,
		@CompanyName,
		@Phone
    )
