if  exists (select * from sys.objects 
            where object_id = object_id('Territories_Update')
              and type in ('P', 'PC'))
    drop procedure Territories_Update
go
create procedure Territories_Update
	@TerritoryID nvarchar,
	@TerritoryDescription nchar,
	@RegionID int
as
    update Territories
    set
		TerritoryDescription = @TerritoryDescription,
		RegionID = @RegionID
    where
		TerritoryID = @TerritoryID
