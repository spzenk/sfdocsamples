if  exists (select * from sys.objects 
            where object_id = object_id('Region_Update')
              and type in ('P', 'PC'))
    drop procedure Region_Update
go
create procedure Region_Update
	@RegionID int,
	@RegionDescription nchar
as
    update Region
    set
		RegionDescription = @RegionDescription
    where
		RegionID = @RegionID
