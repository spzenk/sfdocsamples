if  exists (select * from sys.objects 
            where object_id = object_id('Shippers_Update')
              and type in ('P', 'PC'))
    drop procedure Shippers_Update
go
create procedure Shippers_Update
	@ShipperID int,
	@CompanyName nvarchar,
	@Phone nvarchar
as
    update Shippers
    set
		CompanyName = @CompanyName,
		Phone = @Phone
    where
		ShipperID = @ShipperID
