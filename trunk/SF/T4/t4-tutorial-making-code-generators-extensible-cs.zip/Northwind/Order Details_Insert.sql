if  exists (select * from sys.objects 
            where object_id = object_id('Order Details_Insert')
              and type in ('P', 'PC'))
    drop procedure Order Details_Insert
go
create procedure Order Details_Insert
	@OrderID int,
	@ProductID int,
	@UnitPrice money,
	@Quantity smallint,
	@Discount real
as
    insert into Order Details
    (
		OrderID,
		ProductID,
		UnitPrice,
		Quantity,
		Discount
    )
    values
    (
		@OrderID,
		@ProductID,
		@UnitPrice,
		@Quantity,
		@Discount
    )
