if  exists (select * from sys.objects 
            where object_id = object_id('Categories_Update')
              and type in ('P', 'PC'))
    drop procedure Categories_Update
go
create procedure Categories_Update
	@CategoryID int,
	@CategoryName nvarchar,
	@Description ntext,
	@Picture image
as
    update Categories
    set
		CategoryName = @CategoryName,
		Description = @Description,
		Picture = @Picture
    where
		CategoryID = @CategoryID
