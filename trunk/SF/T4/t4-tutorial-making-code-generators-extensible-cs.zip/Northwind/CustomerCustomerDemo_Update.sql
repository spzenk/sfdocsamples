if  exists (select * from sys.objects 
            where object_id = object_id('CustomerCustomerDemo_Update')
              and type in ('P', 'PC'))
    drop procedure CustomerCustomerDemo_Update
go
create procedure CustomerCustomerDemo_Update
	@CustomerID nchar,
	@CustomerTypeID nchar
as
    update CustomerCustomerDemo
    set
    where
		CustomerID = @CustomerID
		CustomerTypeID = @CustomerTypeID
