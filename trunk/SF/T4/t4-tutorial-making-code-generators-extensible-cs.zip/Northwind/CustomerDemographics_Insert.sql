if  exists (select * from sys.objects 
            where object_id = object_id('CustomerDemographics_Insert')
              and type in ('P', 'PC'))
    drop procedure CustomerDemographics_Insert
go
create procedure CustomerDemographics_Insert
	@CustomerTypeID nchar,
	@CustomerDesc ntext
as
    insert into CustomerDemographics
    (
		CustomerTypeID,
		CustomerDesc
    )
    values
    (
		@CustomerTypeID,
		@CustomerDesc
    )
