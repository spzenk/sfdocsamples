if  exists (select * from sys.objects 
            where object_id = object_id('Employees_Delete')
              and type in ('P', 'PC'))
    drop procedure Employees_Delete
go
create procedure Employees_Delete
	@EmployeeID int
as
    delete from Employees
    where
		EmployeeID = @EmployeeID
