if  exists (select * from sys.objects 
            where object_id = object_id('Order Details_Update')
              and type in ('P', 'PC'))
    drop procedure Order Details_Update
go
create procedure Order Details_Update
	@OrderID int,
	@ProductID int,
	@UnitPrice money,
	@Quantity smallint,
	@Discount real
as
    update Order Details
    set
		UnitPrice = @UnitPrice,
		Quantity = @Quantity,
		Discount = @Discount
    where
		OrderID = @OrderID
		ProductID = @ProductID
