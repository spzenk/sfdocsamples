if  exists (select * from sys.objects 
            where object_id = object_id('EmployeeTerritories_Insert')
              and type in ('P', 'PC'))
    drop procedure EmployeeTerritories_Insert
go
create procedure EmployeeTerritories_Insert
	@EmployeeID int,
	@TerritoryID nvarchar
as
    insert into EmployeeTerritories
    (
		EmployeeID,
		TerritoryID
    )
    values
    (
		@EmployeeID,
		@TerritoryID
    )
