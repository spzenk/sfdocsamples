if  exists (select * from sys.objects 
            where object_id = object_id('CustomerCustomerDemo_Insert')
              and type in ('P', 'PC'))
    drop procedure CustomerCustomerDemo_Insert
go
create procedure CustomerCustomerDemo_Insert
	@CustomerID nchar,
	@CustomerTypeID nchar
as
    insert into CustomerCustomerDemo
    (
		CustomerID,
		CustomerTypeID
    )
    values
    (
		@CustomerID,
		@CustomerTypeID
    )
