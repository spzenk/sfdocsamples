if  exists (select * from sys.objects 
            where object_id = object_id('Categories_Delete')
              and type in ('P', 'PC'))
    drop procedure Categories_Delete
go
create procedure Categories_Delete
	@CategoryID int
as
    delete from Categories
    where
		CategoryID = @CategoryID
