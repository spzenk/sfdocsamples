if  exists (select * from sys.objects 
            where object_id = object_id('Suppliers_Delete')
              and type in ('P', 'PC'))
    drop procedure Suppliers_Delete
go
create procedure Suppliers_Delete
	@SupplierID int
as
    delete from Suppliers
    where
		SupplierID = @SupplierID
