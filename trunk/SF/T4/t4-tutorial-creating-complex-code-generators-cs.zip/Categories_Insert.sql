create procedure Categories_Insert
	@CategoryID int,
	@CategoryName nvarchar,
	@Description ntext,
	@Picture image
as
    insert into Categories
    (
		CategoryID,
		CategoryName,
		Description,
		Picture
    )
    values
    (
		@CategoryID,
		@CategoryName,
		@Description,
		@Picture
    )
