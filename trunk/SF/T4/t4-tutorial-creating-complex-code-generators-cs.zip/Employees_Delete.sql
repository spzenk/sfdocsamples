create procedure Employees_Delete
	@EmployeeID int
as
    delete from Employees
    where
		EmployeeID = @EmployeeID
