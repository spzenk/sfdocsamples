create procedure Territories_Delete
	@TerritoryID nvarchar
as
    delete from Territories
    where
		TerritoryID = @TerritoryID
