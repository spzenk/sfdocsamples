create procedure Customers_Delete
	@CustomerID nchar
as
    delete from Customers
    where
		CustomerID = @CustomerID
