create procedure EmployeeTerritories_Insert
	@EmployeeID int,
	@TerritoryID nvarchar
as
    insert into EmployeeTerritories
    (
		EmployeeID,
		TerritoryID
    )
    values
    (
		@EmployeeID,
		@TerritoryID
    )
