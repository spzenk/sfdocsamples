create procedure Territories_Insert
	@TerritoryID nvarchar,
	@TerritoryDescription nchar,
	@RegionID int
as
    insert into Territories
    (
		TerritoryID,
		TerritoryDescription,
		RegionID
    )
    values
    (
		@TerritoryID,
		@TerritoryDescription,
		@RegionID
    )
