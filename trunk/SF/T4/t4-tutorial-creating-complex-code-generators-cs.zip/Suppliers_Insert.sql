create procedure Suppliers_Insert
	@SupplierID int,
	@CompanyName nvarchar,
	@ContactName nvarchar,
	@ContactTitle nvarchar,
	@Address nvarchar,
	@City nvarchar,
	@Region nvarchar,
	@PostalCode nvarchar,
	@Country nvarchar,
	@Phone nvarchar,
	@Fax nvarchar,
	@HomePage ntext
as
    insert into Suppliers
    (
		SupplierID,
		CompanyName,
		ContactName,
		ContactTitle,
		Address,
		City,
		Region,
		PostalCode,
		Country,
		Phone,
		Fax,
		HomePage
    )
    values
    (
		@SupplierID,
		@CompanyName,
		@ContactName,
		@ContactTitle,
		@Address,
		@City,
		@Region,
		@PostalCode,
		@Country,
		@Phone,
		@Fax,
		@HomePage
    )
