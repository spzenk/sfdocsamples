create procedure Categories_Update
	@CategoryID int,
	@CategoryName nvarchar,
	@Description ntext,
	@Picture image
as
    update Categories
    set
		CategoryName = @CategoryName,
		Description = @Description,
		Picture = @Picture
    where
		CategoryID = @CategoryID
