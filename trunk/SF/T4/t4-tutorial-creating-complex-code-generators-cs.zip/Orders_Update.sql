create procedure Orders_Update
	@OrderID int,
	@CustomerID nchar,
	@EmployeeID int,
	@OrderDate datetime,
	@RequiredDate datetime,
	@ShippedDate datetime,
	@ShipVia int,
	@Freight money,
	@ShipName nvarchar,
	@ShipAddress nvarchar,
	@ShipCity nvarchar,
	@ShipRegion nvarchar,
	@ShipPostalCode nvarchar,
	@ShipCountry nvarchar
as
    update Orders
    set
		CustomerID = @CustomerID,
		EmployeeID = @EmployeeID,
		OrderDate = @OrderDate,
		RequiredDate = @RequiredDate,
		ShippedDate = @ShippedDate,
		ShipVia = @ShipVia,
		Freight = @Freight,
		ShipName = @ShipName,
		ShipAddress = @ShipAddress,
		ShipCity = @ShipCity,
		ShipRegion = @ShipRegion,
		ShipPostalCode = @ShipPostalCode,
		ShipCountry = @ShipCountry
    where
		OrderID = @OrderID
