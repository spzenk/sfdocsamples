create procedure EmployeeTerritories_Delete
	@EmployeeID int
	@TerritoryID nvarchar
as
    delete from EmployeeTerritories
    where
		EmployeeID = @EmployeeID
		TerritoryID = @TerritoryID
