create procedure CustomerDemographics_Delete
	@CustomerTypeID nchar
as
    delete from CustomerDemographics
    where
		CustomerTypeID = @CustomerTypeID
