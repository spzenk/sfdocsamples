create procedure Region_Insert
	@RegionID int,
	@RegionDescription nchar
as
    insert into Region
    (
		RegionID,
		RegionDescription
    )
    values
    (
		@RegionID,
		@RegionDescription
    )
