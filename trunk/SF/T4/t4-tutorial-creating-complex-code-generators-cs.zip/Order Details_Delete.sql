create procedure Order Details_Delete
	@OrderID int
	@ProductID int
as
    delete from Order Details
    where
		OrderID = @OrderID
		ProductID = @ProductID
