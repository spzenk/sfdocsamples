create procedure Shippers_Insert
	@ShipperID int,
	@CompanyName nvarchar,
	@Phone nvarchar
as
    insert into Shippers
    (
		ShipperID,
		CompanyName,
		Phone
    )
    values
    (
		@ShipperID,
		@CompanyName,
		@Phone
    )
