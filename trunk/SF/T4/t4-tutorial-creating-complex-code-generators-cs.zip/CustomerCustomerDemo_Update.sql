create procedure CustomerCustomerDemo_Update
	@CustomerID nchar,
	@CustomerTypeID nchar
as
    update CustomerCustomerDemo
    set
    where
		CustomerID = @CustomerID
		CustomerTypeID = @CustomerTypeID
