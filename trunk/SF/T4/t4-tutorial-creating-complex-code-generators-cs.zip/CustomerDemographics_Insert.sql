create procedure CustomerDemographics_Insert
	@CustomerTypeID nchar,
	@CustomerDesc ntext
as
    insert into CustomerDemographics
    (
		CustomerTypeID,
		CustomerDesc
    )
    values
    (
		@CustomerTypeID,
		@CustomerDesc
    )
