create procedure Region_Delete
	@RegionID int
as
    delete from Region
    where
		RegionID = @RegionID
