create procedure Products_Update
	@ProductID int,
	@ProductName nvarchar,
	@SupplierID int,
	@CategoryID int,
	@QuantityPerUnit nvarchar,
	@UnitPrice money,
	@UnitsInStock smallint,
	@UnitsOnOrder smallint,
	@ReorderLevel smallint,
	@Discontinued bit,
	@LastEditDate datetime,
	@CreationDate datetime
as
    update Products
    set
		ProductName = @ProductName,
		SupplierID = @SupplierID,
		CategoryID = @CategoryID,
		QuantityPerUnit = @QuantityPerUnit,
		UnitPrice = @UnitPrice,
		UnitsInStock = @UnitsInStock,
		UnitsOnOrder = @UnitsOnOrder,
		ReorderLevel = @ReorderLevel,
		Discontinued = @Discontinued,
		LastEditDate = @LastEditDate,
		CreationDate = @CreationDate
    where
		ProductID = @ProductID
