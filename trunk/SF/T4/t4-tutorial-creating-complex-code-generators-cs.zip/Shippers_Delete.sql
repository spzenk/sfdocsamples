create procedure Shippers_Delete
	@ShipperID int
as
    delete from Shippers
    where
		ShipperID = @ShipperID
