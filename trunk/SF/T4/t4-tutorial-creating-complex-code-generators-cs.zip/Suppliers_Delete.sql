create procedure Suppliers_Delete
	@SupplierID int
as
    delete from Suppliers
    where
		SupplierID = @SupplierID
