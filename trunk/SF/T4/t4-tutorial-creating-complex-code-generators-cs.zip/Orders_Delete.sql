create procedure Orders_Delete
	@OrderID int
as
    delete from Orders
    where
		OrderID = @OrderID
