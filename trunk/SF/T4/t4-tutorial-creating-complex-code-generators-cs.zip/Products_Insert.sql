create procedure Products_Insert
	@ProductID int,
	@ProductName nvarchar,
	@SupplierID int,
	@CategoryID int,
	@QuantityPerUnit nvarchar,
	@UnitPrice money,
	@UnitsInStock smallint,
	@UnitsOnOrder smallint,
	@ReorderLevel smallint,
	@Discontinued bit,
	@LastEditDate datetime,
	@CreationDate datetime
as
    insert into Products
    (
		ProductID,
		ProductName,
		SupplierID,
		CategoryID,
		QuantityPerUnit,
		UnitPrice,
		UnitsInStock,
		UnitsOnOrder,
		ReorderLevel,
		Discontinued,
		LastEditDate,
		CreationDate
    )
    values
    (
		@ProductID,
		@ProductName,
		@SupplierID,
		@CategoryID,
		@QuantityPerUnit,
		@UnitPrice,
		@UnitsInStock,
		@UnitsOnOrder,
		@ReorderLevel,
		@Discontinued,
		@LastEditDate,
		@CreationDate
    )
