create procedure CustomerDemographics_Update
	@CustomerTypeID nchar,
	@CustomerDesc ntext
as
    update CustomerDemographics
    set
		CustomerDesc = @CustomerDesc
    where
		CustomerTypeID = @CustomerTypeID
