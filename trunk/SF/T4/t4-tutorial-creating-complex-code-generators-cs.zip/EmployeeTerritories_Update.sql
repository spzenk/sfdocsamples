create procedure EmployeeTerritories_Update
	@EmployeeID int,
	@TerritoryID nvarchar
as
    update EmployeeTerritories
    set
    where
		EmployeeID = @EmployeeID
		TerritoryID = @TerritoryID
