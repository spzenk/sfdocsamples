create procedure Region_Update
	@RegionID int,
	@RegionDescription nchar
as
    update Region
    set
		RegionDescription = @RegionDescription
    where
		RegionID = @RegionID
