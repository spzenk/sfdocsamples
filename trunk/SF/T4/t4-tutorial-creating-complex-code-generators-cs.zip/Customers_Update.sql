create procedure Customers_Update
	@CustomerID nchar,
	@CompanyName nvarchar,
	@ContactName nvarchar,
	@ContactTitle nvarchar,
	@Address nvarchar,
	@City nvarchar,
	@Region nvarchar,
	@PostalCode nvarchar,
	@Country nvarchar,
	@Phone nvarchar,
	@Fax nvarchar
as
    update Customers
    set
		CompanyName = @CompanyName,
		ContactName = @ContactName,
		ContactTitle = @ContactTitle,
		Address = @Address,
		City = @City,
		Region = @Region,
		PostalCode = @PostalCode,
		Country = @Country,
		Phone = @Phone,
		Fax = @Fax
    where
		CustomerID = @CustomerID
