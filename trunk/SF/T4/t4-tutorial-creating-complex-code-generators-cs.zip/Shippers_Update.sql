create procedure Shippers_Update
	@ShipperID int,
	@CompanyName nvarchar,
	@Phone nvarchar
as
    update Shippers
    set
		CompanyName = @CompanyName,
		Phone = @Phone
    where
		ShipperID = @ShipperID
