create procedure Categories_Delete
	@CategoryID int
as
    delete from Categories
    where
		CategoryID = @CategoryID
