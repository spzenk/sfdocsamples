create procedure CustomerCustomerDemo_Delete
	@CustomerID nchar
	@CustomerTypeID nchar
as
    delete from CustomerCustomerDemo
    where
		CustomerID = @CustomerID
		CustomerTypeID = @CustomerTypeID
