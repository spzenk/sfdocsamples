create procedure Territories_Update
	@TerritoryID nvarchar,
	@TerritoryDescription nchar,
	@RegionID int
as
    update Territories
    set
		TerritoryDescription = @TerritoryDescription,
		RegionID = @RegionID
    where
		TerritoryID = @TerritoryID
