create procedure CustomerCustomerDemo_Insert
	@CustomerID nchar,
	@CustomerTypeID nchar
as
    insert into CustomerCustomerDemo
    (
		CustomerID,
		CustomerTypeID
    )
    values
    (
		@CustomerID,
		@CustomerTypeID
    )
