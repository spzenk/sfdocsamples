#region Copyright Information
/*
 * (C)  2005-2007, EduJini
 *
 * For terms and usage, please see the LICENSE file
 * provided alongwith or contact copyright@edujinionline.com
 *
 * http://www.edujinionline.com
 *
 */
#endregion

using System;

namespace ShoppingCartConsumer
{
	public class MainClass
	{
		public static void Main(string[] args)
		{
			ShoppingCartServiceClient client = new ShoppingCartServiceClient();

			string[] users = new string[] { "gvaish", "edujini", "other" };

			foreach(string user in users)
			{
				Console.WriteLine("User: {0}", user);
				Console.WriteLine("\tExists:           {0}", client.CheckUserExists(user));
				DateTime? time = client.GetLastTransactionTime(user);
				if(time.HasValue)
				{
					Console.WriteLine("\tLast Transaction: {0}", time.Value);
				} else
				{
					Console.WriteLine("\tNever transacted");
				}
			}

			Console.WriteLine();
		}
	}
}