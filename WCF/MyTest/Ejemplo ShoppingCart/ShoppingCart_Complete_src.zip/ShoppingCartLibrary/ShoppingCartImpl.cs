#region Copyright Information
/*
 * (C)  2005-2007, Gaurav Vaish
 *
 * For terms and usage, please see the LICENSE file
 * provided alongwith or contact gaurav[dot]vaish[AT]gmail[dot]com
 *
 * http://www.mastergaurav.com
 * http://www.mastergaurav.org
 *
 */
#endregion

using System;

namespace ShoppingCartLibrary
{
	public class ShoppingCartImpl : IShoppingCartService
	{
		#region IShoppingCartService Members
		public bool CheckUserExists(string username)
		{
			if(username == "gvaish" || username == "edujini")
			{
				return true;
			}
			return false;
		}

		public DateTime? GetLastTransactionTime(string username)
		{
			if(username == "gvaish")
			{
				return DateTime.Now.AddDays(-3);
			}
			if(username == "edujini")
			{
				return DateTime.Now.AddHours(-3);
			}
			return null;
		}
		#endregion
	}
}