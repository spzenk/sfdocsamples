#region Copyright Information
/*
 * (C)  2005-2007, Gaurav Vaish
 *
 * For terms and usage, please see the LICENSE file
 * provided alongwith or contact gaurav[dot]vaish[AT]gmail[dot]com
 *
 * http://www.mastergaurav.com
 * http://www.mastergaurav.org
 *
 */
#endregion

using System;
using System.ServiceModel;

namespace ShoppingCartLibrary
{
	[ServiceContract]
	public interface IShoppingCartService
	{
		[OperationContract]
		bool CheckUserExists(string username);

		[OperationContract]
		DateTime? GetLastTransactionTime(string username);
	}
}
