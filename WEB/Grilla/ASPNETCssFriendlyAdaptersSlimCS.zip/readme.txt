ASP.NET 2.0 CSS Friendly Control Adapters 1.0
Last Updated: 20 November 2006
http://www.asp.net/cssadapters

Get Started----------------

    If you are using Visual Studio, press Ctrl-F5 to start using this web site
    or choose "Start Without Debugging" from the Debug menu.
    
Goals----------------------

    This web site uses a set of ASP.NET 2.0 CSS Friendly Control Adapters
    (http://www.asp.net/cssadapters) to produce HTML that is particularly easy to style with CSS.
    
Feedback-------------------

    Getting feedback is important to us. Please post comments and 
    suggestions or report bugs on the forum at: http://forums.asp.net/1018/ShowForum.aspx.